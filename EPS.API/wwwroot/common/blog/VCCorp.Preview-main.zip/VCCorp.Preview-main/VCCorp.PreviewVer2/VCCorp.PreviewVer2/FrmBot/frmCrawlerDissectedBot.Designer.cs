﻿
namespace VCCorp.PreviewVer2.FrmBot
{
    partial class frmCrawlerDissectedBot
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btLoad = new System.Windows.Forms.Button();
            this.btEdit = new System.Windows.Forms.Button();
            this.btAdd = new System.Windows.Forms.Button();
            this.btShowDetail = new System.Windows.Forms.Button();
            this.lblCategoryError = new System.Windows.Forms.Label();
            this.lblCategoryDissected = new System.Windows.Forms.Label();
            this.lblCategoryUndissected = new System.Windows.Forms.Label();
            this.lblCategoryAll = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtUrl = new System.Windows.Forms.TextBox();
            this.gridPriview = new System.Windows.Forms.DataGridView();
            this.Id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Url = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Domain = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Title = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CreatedDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SendDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CategoryId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.gridPriview)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btLoad
            // 
            this.btLoad.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btLoad.Location = new System.Drawing.Point(777, 86);
            this.btLoad.Name = "btLoad";
            this.btLoad.Size = new System.Drawing.Size(149, 25);
            this.btLoad.TabIndex = 16;
            this.btLoad.Text = "Load Preview";
            this.btLoad.UseVisualStyleBackColor = true;
            // 
            // btEdit
            // 
            this.btEdit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btEdit.Location = new System.Drawing.Point(1087, 86);
            this.btEdit.Name = "btEdit";
            this.btEdit.Size = new System.Drawing.Size(111, 25);
            this.btEdit.TabIndex = 15;
            this.btEdit.Text = "Bóc lại";
            this.btEdit.UseVisualStyleBackColor = true;
            // 
            // btAdd
            // 
            this.btAdd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btAdd.Location = new System.Drawing.Point(932, 86);
            this.btAdd.Name = "btAdd";
            this.btAdd.Size = new System.Drawing.Size(149, 25);
            this.btAdd.TabIndex = 13;
            this.btAdd.Text = "Bắt đầu bóc";
            this.btAdd.UseVisualStyleBackColor = true;
            // 
            // btShowDetail
            // 
            this.btShowDetail.Location = new System.Drawing.Point(355, 21);
            this.btShowDetail.Name = "btShowDetail";
            this.btShowDetail.Size = new System.Drawing.Size(149, 25);
            this.btShowDetail.TabIndex = 12;
            this.btShowDetail.Text = "Xem chi tiết đã bóc";
            this.btShowDetail.UseVisualStyleBackColor = true;
            // 
            // lblCategoryError
            // 
            this.lblCategoryError.AutoSize = true;
            this.lblCategoryError.Location = new System.Drawing.Point(352, 90);
            this.lblCategoryError.Name = "lblCategoryError";
            this.lblCategoryError.Size = new System.Drawing.Size(15, 16);
            this.lblCategoryError.TabIndex = 11;
            this.lblCategoryError.Text = "0";
            // 
            // lblCategoryDissected
            // 
            this.lblCategoryDissected.AutoSize = true;
            this.lblCategoryDissected.Location = new System.Drawing.Point(161, 90);
            this.lblCategoryDissected.Name = "lblCategoryDissected";
            this.lblCategoryDissected.Size = new System.Drawing.Size(15, 16);
            this.lblCategoryDissected.TabIndex = 10;
            this.lblCategoryDissected.Text = "0";
            // 
            // lblCategoryUndissected
            // 
            this.lblCategoryUndissected.AutoSize = true;
            this.lblCategoryUndissected.Location = new System.Drawing.Point(352, 60);
            this.lblCategoryUndissected.Name = "lblCategoryUndissected";
            this.lblCategoryUndissected.Size = new System.Drawing.Size(15, 16);
            this.lblCategoryUndissected.TabIndex = 9;
            this.lblCategoryUndissected.Text = "0";
            // 
            // lblCategoryAll
            // 
            this.lblCategoryAll.AutoSize = true;
            this.lblCategoryAll.Location = new System.Drawing.Point(161, 60);
            this.lblCategoryAll.Name = "lblCategoryAll";
            this.lblCategoryAll.Size = new System.Drawing.Size(15, 16);
            this.lblCategoryAll.TabIndex = 8;
            this.lblCategoryAll.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label4.Location = new System.Drawing.Point(207, 60);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(142, 16);
            this.label4.TabIndex = 7;
            this.label4.Text = "Chuyên mục chưa bóc:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(207, 90);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(101, 16);
            this.label3.TabIndex = 6;
            this.label3.Text = "Chuyên mục lỗi:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label2.Location = new System.Drawing.Point(8, 90);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(147, 16);
            this.label2.TabIndex = 5;
            this.label2.Text = "Số chuyên mục đã bóc:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(117, 16);
            this.label1.TabIndex = 4;
            this.label1.Text = "Tổng chuyên mục:";
            // 
            // txtUrl
            // 
            this.txtUrl.Location = new System.Drawing.Point(6, 22);
            this.txtUrl.Name = "txtUrl";
            this.txtUrl.Size = new System.Drawing.Size(343, 22);
            this.txtUrl.TabIndex = 1;
            // 
            // gridPriview
            // 
            this.gridPriview.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gridPriview.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gridPriview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridPriview.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Id,
            this.Url,
            this.Domain,
            this.Title,
            this.CreatedDate,
            this.SendDate,
            this.Status,
            this.CategoryId});
            this.gridPriview.Location = new System.Drawing.Point(6, 117);
            this.gridPriview.Name = "gridPriview";
            this.gridPriview.Size = new System.Drawing.Size(1192, 468);
            this.gridPriview.TabIndex = 0;
            // 
            // Id
            // 
            this.Id.HeaderText = "Id";
            this.Id.Name = "Id";
            this.Id.Visible = false;
            // 
            // Url
            // 
            this.Url.FillWeight = 146.5416F;
            this.Url.HeaderText = "Url";
            this.Url.Name = "Url";
            this.Url.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // Domain
            // 
            this.Domain.FillWeight = 110.4283F;
            this.Domain.HeaderText = "Domain";
            this.Domain.Name = "Domain";
            // 
            // Title
            // 
            this.Title.HeaderText = "Tiêu đề";
            this.Title.Name = "Title";
            // 
            // CreatedDate
            // 
            this.CreatedDate.FillWeight = 67.69177F;
            this.CreatedDate.HeaderText = "Ngày tạo";
            this.CreatedDate.Name = "CreatedDate";
            // 
            // SendDate
            // 
            this.SendDate.FillWeight = 74.691F;
            this.SendDate.HeaderText = "Ngày gửi";
            this.SendDate.Name = "SendDate";
            // 
            // Status
            // 
            this.Status.FillWeight = 100.6473F;
            this.Status.HeaderText = "Trạng thái";
            this.Status.Name = "Status";
            // 
            // CategoryId
            // 
            this.CategoryId.HeaderText = "CategoryId";
            this.CategoryId.Name = "CategoryId";
            this.CategoryId.Visible = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btLoad);
            this.groupBox1.Controls.Add(this.btEdit);
            this.groupBox1.Controls.Add(this.btAdd);
            this.groupBox1.Controls.Add(this.btShowDetail);
            this.groupBox1.Controls.Add(this.lblCategoryError);
            this.groupBox1.Controls.Add(this.lblCategoryDissected);
            this.groupBox1.Controls.Add(this.lblCategoryUndissected);
            this.groupBox1.Controls.Add(this.lblCategoryAll);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtUrl);
            this.groupBox1.Controls.Add(this.gridPriview);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1204, 591);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Danh sách chuyên mục-Bot";
            // 
            // frmCrawlerDissectedBot
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1204, 591);
            this.Controls.Add(this.groupBox1);
            this.Name = "frmCrawlerDissectedBot";
            this.Text = "Danh sách chuyên mục-Bot";
            ((System.ComponentModel.ISupportInitialize)(this.gridPriview)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btLoad;
        private System.Windows.Forms.Button btEdit;
        private System.Windows.Forms.Button btAdd;
        private System.Windows.Forms.Button btShowDetail;
        private System.Windows.Forms.Label lblCategoryError;
        private System.Windows.Forms.Label lblCategoryDissected;
        private System.Windows.Forms.Label lblCategoryUndissected;
        private System.Windows.Forms.Label lblCategoryAll;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtUrl;
        private System.Windows.Forms.DataGridView gridPriview;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Id;
        private System.Windows.Forms.DataGridViewTextBoxColumn Url;
        private System.Windows.Forms.DataGridViewTextBoxColumn Domain;
        private System.Windows.Forms.DataGridViewTextBoxColumn Title;
        private System.Windows.Forms.DataGridViewTextBoxColumn CreatedDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn SendDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Status;
        private System.Windows.Forms.DataGridViewTextBoxColumn CategoryId;
    }
}