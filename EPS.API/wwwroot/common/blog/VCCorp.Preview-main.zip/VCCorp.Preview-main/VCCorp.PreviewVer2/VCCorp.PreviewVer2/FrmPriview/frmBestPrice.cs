﻿using CefSharp.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using VCCorp.PreviewCore.BUS;
using VCCorp.PreviewCore.Common;
using VCCorp.PreviewCore.DAO;
using VCCorp.PreviewCore.DTO;
using VCCorp.PreviewVer2.Common;

namespace VCCorp.PreviewVer2.FrmPriview
{
    public partial class frmBestPrice : Form
    {
        private ChromiumWebBrowser _browser;
        private Control control;
        private readonly CategoryDAO categoryDAO = null;
        private readonly SiteDAO siteDAO = null;
        private readonly ArticleDAO articleDAO = null;
        private List<CategoryDTO> dataUrl = new List<CategoryDTO>();
        public static int _siteId = 0;
        private static string _url = "";

        public frmBestPrice(string url, int siteId)
        {
            InitializeComponent();
            AutoShutDown.Start();
            control = rtbResult;
            categoryDAO = new CategoryDAO(ConnectionDAO.ConnectionToTableLinkProduct);
            siteDAO = new SiteDAO(ConnectionDAO.ConnectionToTableLinkProduct);
            articleDAO = new ArticleDAO(ConnectionDAO.ConnectionToTableLinkProduct);
            this.Text = $"Kết quả bóc tách trang {url.ToUpper()}";
            Utilities.WriteLogToTxtFile($"Bóc tách trang {url.ToUpper()}");
            txtUrl.Text = url;
            _url = url;
            _siteId = siteId;
            LoadData();
        }

        public async void LoadData()
        {
            dataUrl = categoryDAO.GetSiteBySiteId(_siteId);
            if (dataUrl.Count > 0)
            {
                Utilities.WriteToBoxResult($"Bắt đầu bóc tại trang {_url} tại chuyên mục {dataUrl[0].Description.ToUpper()}", rtbResult);
            }
            else
            {
                string message = "Không có trang Priviews trong hệ thống! Hãy thêm mới.";
                string noti = "Thông báo";
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                DialogResult result = MessageBox.Show(message, noti, buttons);
            }
            await Task.Delay(2_000);
        }

        private async void btnRun_Click(object sender, EventArgs e)
        {
            if (dataUrl.Count > 0)
            {
                Utilities.WriteToBoxResult($"---Dowload HTML tốt: {txtUrl.Text}", rtbResult);
                this.WindowState = FormWindowState.Maximized;
                _browser = Utilities.InitBrowser(txtUrl.Text);
                this.pnlBrowser.Controls.Add(_browser);
                _browser.Width = pnlBrowser.Width;
                _browser.Height = pnlBrowser.Height;
                _browser.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
                _browser.Dock = DockStyle.Fill;
                await Task.Delay(10_000);
                ParserBestPrice parser = new ParserBestPrice(_browser);
                foreach (var item in dataUrl)
                {
                    await parser.CrawlDataPost(item.Url, item.Id);
                    await siteDAO.UpdateSiteStatusAndCrawlDate(_siteId);
                    siteDAO.Dispose();
                }
            }
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            if (dataUrl.Count > 0)
            {
                this.WindowState = FormWindowState.Maximized;
                _browser = Utilities.InitBrowser(txtUrl.Text);
                this.pnlBrowser.Controls.Add(_browser);
                _browser.Width = pnlBrowser.Width;
                _browser.Height = pnlBrowser.Height;
                _browser.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
                _browser.Dock = DockStyle.Fill;
                await Task.Delay(10_000);
                ParserBestPrice parser = new ParserBestPrice(_browser);
                int loop = 0;
                int countUrl = 0;
                while (true)
                {
                    var item = dataUrl[loop];
                    countUrl = articleDAO.GetLinkByCategoryId(item.Id).Count;
                    loop++;
                    if (loop == dataUrl.Count)
                    {
                        loop = 0;
                        await Task.Delay(TimeSpan.FromSeconds(5));
                    }

                    if (countUrl == 0)
                    {
                        continue;
                    }
                    await parser.CrawlDetailPost(item.Id);
                }
            }
        }

        private void AutoShutDown_Tick(object sender, EventArgs e)
        {
            if (DateTime.Now.Hour == 0)
            {
                ListNameFrm.listNameFrms.Remove(_url);
                ListNameFrm.countFrm--;
                AutoShutDown.Stop();
                this.Close();
                try
                {
                    this.Dispose(true);
                }
                catch (Exception ex)
                {
                    var type = this.GetType().Name;
                    Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
                }
            }
        }
    }
}
