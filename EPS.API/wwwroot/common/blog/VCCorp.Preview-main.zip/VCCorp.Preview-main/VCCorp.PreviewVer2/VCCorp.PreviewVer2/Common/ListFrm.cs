﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VCCorp.PreviewVer2.Common
{
    public class ListFrm
    {
        public string Url { get; set; }
        public string frm { get; set; }

        public static List<ListFrm> listFrms = new List<ListFrm>()
        {
            new ListFrm()
            {
                Url = "https://www.agoda.com/",
                frm = "frmAgoda"
            },
            new ListFrm()
            {
                Url = "https://www.airbnb.com.vn/",
                frm = "frmAirbnb"
            },
            new ListFrm()
            {
                Url = "https://www.bestprice.vn/",
                frm = "frmBestPrice"
            },
             new ListFrm()
            {
                Url = "https://www.booking.com/",
                frm = "frmBooking"
            },
            new ListFrm()
            {
                Url = "https://www.chudu24.com/",
                frm = "frmChudu24"
            },
            new ListFrm()
            {
                Url = "https://www.expedia.com.vn/",
                frm = "frmExpedia"
            },
            new ListFrm()
            {
                Url = "https://vi.hotels.com/",
                frm = "frmHotel"
            },
            new ListFrm()
            {
                Url = "https://www.ivivu.com/",
                frm = "frmIVivu"
            },
            new ListFrm()
            {
                Url = "https://www.kkday.com/",
                frm = "frmKkday"
            },
            new ListFrm()
            {
                Url = "https://mytour.vn/",
                frm = "frmMyTour"
            },
            new ListFrm()
            {
                Url = "https://pasgo.vn/",
                frm = "frmPasgo"
            },
            new ListFrm()
            {
                Url = "https://riviu.vn/",
                frm = "frmRiviu"
            },
            new ListFrm()
            {
                Url = "https://www.vntrip.vn/",
                frm = "frmVnTrip"
            },
            new ListFrm()
            {
                Url = "https://www.foody.vn/",
                frm = "frmFoody"
            }
        };
    }

    public class ListNameFrm
    {
        public static List<string> listNameFrms = new List<string>();
        public static int countFrm { get; set; }
    }
}
