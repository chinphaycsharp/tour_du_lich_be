﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using VCCorp.PreviewCore.Common;
using VCCorp.PreviewCore.DAO;
using VCCorp.PreviewCore.DTO;

namespace VCCorp.PreviewVer2.FrmAdmin
{
    public partial class frmEditCategoryAdmin : Form
    {
        private readonly CategoryDAO categoryDAO = null;
        private CategoryDTO _category = null;
        public frmEditCategoryAdmin(CategoryDTO category)
        {
            InitializeComponent();
            categoryDAO = new CategoryDAO(ConnectionDAO.ConnectionToTableLinkProduct);
            txtDomain.Text = category.Domain;
            txtDomain.Enabled = false;
            txtUrl.Text = category.Url;
            txtDescription.Text = category.Description;
            _category = category;
        }

        private async void btsave_Click(object sender, EventArgs e)
        {
            if (_category != null)
            {
                int result = await categoryDAO.UpdateCategoryById(_category.Id, txtUrl.Text, txtDescription.Text);
                categoryDAO.Dispose();
                if (result == 1)
                {
                    string message = "Sửa thông tin chuyên mục thành công!";
                    string noti = "Thông báo";
                    MessageBoxButtons buttons = MessageBoxButtons.OK;
                    DialogResult resultUpdate = MessageBox.Show(message, noti, buttons);
                    if (resultUpdate == DialogResult.OK)
                    {
                        this.Close();
                        try
                        {
                            this.Dispose(true);
                        }
                        catch (Exception ex)
                        {
                            var type = this.GetType().Name;
                            Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
                        }
                    }
                }
                else
                {
                    string message = "Sửa thông tin chuyên mục thất bại!";
                    string noti = "Thông báo";
                    MessageBoxButtons buttons = MessageBoxButtons.OK;
                    DialogResult resultUpdate = MessageBox.Show(message, noti, buttons);
                }
            }
        }

        private void frmEditCategoryAdmin_FormClosed(object sender, FormClosedEventArgs e)
        {
            frmManageCategoryAdmin frm = Application.OpenForms.OfType<frmManageCategoryAdmin>().FirstOrDefault();
            if (frm != null)
            {
                frm.LoadData();
            }
        }

        private void btback_Click(object sender, EventArgs e)
        {
            this.Close();
            try
            {
                this.Dispose(true);
            }
            catch(Exception ex)
            {
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }
        }
    }
}
