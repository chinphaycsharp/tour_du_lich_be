﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using VCCorp.PreviewCore.Common;
using VCCorp.PreviewCore.DAO;
using VCCorp.PreviewCore.DTO;

namespace VCCorp.PreviewVer2.FrmAdmin
{
    public partial class frmManageCategoryAdmin : Form
    {
        private readonly CategoryDAO categoryDAO = null;
        private SiteDTO _site;
        private CategoryDTO _category;
        public frmManageCategoryAdmin(SiteDTO site)
        {
            InitializeComponent();
            categoryDAO = new CategoryDAO(ConnectionDAO.ConnectionToTableLinkProduct);
            _site = site;
            HandleButtonEdit();
            HandleButtonDelete();
            HandleButtonShowDetail();
            LoadData();
        }

        public void HandleButtonEdit()
        {
            btEdit.Enabled = !btEdit.Enabled;
        }

        public void HandleButtonDelete()
        {
            btDelete.Enabled = !btDelete.Enabled;
        }

        public void HandleButtonShowDetail()
        {
            btShowDetail.Enabled = !btShowDetail.Enabled;
        }

        public void LoadData()
        {
            gridCategories.Rows.Clear();
            List<CategoryDTO> dataUrl = categoryDAO.GetSiteBySiteId(_site.Id);
            categoryDAO.Dispose();
            LoadCountCategory(dataUrl);
            if (dataUrl.Count > 0)
            {
                string message = "";
                try
                {
                    foreach (var item in dataUrl)
                    {
                        DataGridViewRow newRow = new DataGridViewRow();
                        newRow.CreateCells(gridCategories);
                        newRow.Cells[0].Value = item.Id;
                        newRow.Cells[1].Value = item.Url;
                        newRow.Cells[2].Value = item.Domain;
                        newRow.Cells[3].Value = item.Description;
                        newRow.Cells[4].Value = item.CreatedDateStr;
                        newRow.Cells[5].Value = item.SendDateStr;
                        newRow.Cells[6].Value = item.StatusStr;
                        gridCategories.Rows.Add(newRow);
                    }
                }
                catch (Exception ex)
                {
                    message = ex.Message;
                    var type = this.GetType().Name;
                    Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
                }
            }
            else
            {
                string message = $"Hiện chưa có chuyên mục nào thuộc trang {_site.Url.ToUpper()}! Hãy thêm mới.";
                string noti = "Thông báo";
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                DialogResult result = MessageBox.Show(message, noti, buttons);
                if (result == DialogResult.Yes)
                {
                    frmAddCategoryAdmin frm = new frmAddCategoryAdmin(0,"");
                    frm.Show();
                }
                else
                {
                    // Do something  
                }
            }
        }

        public void LoadCountCategory(List<CategoryDTO> data)
        {
            lblCategoryAll.Text = data.Count.ToString();
            lblCategoryUndissected.Text = data.Where(x => x.Status == 0).Count().ToString();
            lblCategoryDissected.Text = data.Where(x => x.Status == 1).Count().ToString();
            lblCategoryError.Text = data.Where(x => x.Status == -1).Count().ToString();
        }

        private void gridCategories_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                btShowDetail.Enabled = true;
                btEdit.Enabled = true;
                btDelete.Enabled = true;
                try
                {
                    DataGridViewRow row = gridCategories.SelectedRows[0];
                    int Id = Convert.ToInt32(row.Cells[0].Value);
                    txtUrl.Text = row.Cells[1].Value.ToString();
                    if (Id > 0)
                    {
                        _category = categoryDAO.GetCategoryById(Id);
                        categoryDAO.Dispose();
                    }
                }
                catch (Exception ex)
                {
                    string message = ex.Message;
                    var type = this.GetType().Name;
                    Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
                }
            }
        }

        private void btAdd_Click(object sender, EventArgs e)
        {
            HandleButtonEdit();
            HandleButtonDelete();
            HandleButtonShowDetail();
            frmAddCategoryAdmin frm = new frmAddCategoryAdmin(_site.Id,_site.Url);
            frm.Show();
        }

        private void btEdit_Click(object sender, EventArgs e)
        {
            if (_category != null)
            {
                btEdit.Enabled = false;
                btDelete.Enabled = false;
                frmEditCategoryAdmin frm = new frmEditCategoryAdmin(_category);
                frm.Show();
            }
            txtUrl.Text = "";
        }

        private async void btDelete_Click(object sender, EventArgs e)
        {
            if (_category != null)
            {

                int resultDelete = await categoryDAO.DeleteCategoryById(_category.Id);
                categoryDAO.Dispose();
                string message = "";
                string noti = "Thông báo";
                MessageBoxButtons buttons = MessageBoxButtons.OK;
                if (resultDelete == 1)
                {
                    message = "Xóa thành công!";
                    DialogResult result = MessageBox.Show(message, noti, buttons);
                }
                else
                {
                    message = "Xóa thất bại!";
                    DialogResult result = MessageBox.Show(message, noti, buttons);
                }
                btDelete.Enabled = false;
                btEdit.Enabled = false;
                LoadData();
            }
        }
    }
}
