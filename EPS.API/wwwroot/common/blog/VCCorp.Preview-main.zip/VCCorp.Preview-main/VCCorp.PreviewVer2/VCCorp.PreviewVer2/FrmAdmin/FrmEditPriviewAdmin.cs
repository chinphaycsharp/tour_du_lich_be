﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using VCCorp.PreviewCore.Common;
using VCCorp.PreviewCore.DAO;
using VCCorp.PreviewCore.DTO;

namespace VCCorp.PreviewVer2.FrmAdmin
{
    public partial class FrmEditPriviewAdmin : Form
    {
        private readonly SiteDAO siteDAO = null;
        private SiteDTO site = null;
        public FrmEditPriviewAdmin(SiteDTO dto)
        {
            InitializeComponent();
            siteDAO = new SiteDAO(ConnectionDAO.ConnectionToTableLinkProduct);
            site = dto;
            txtUrl.Text = dto.Url;
            numOrderDissection.Value = dto.OrderDissection;
        }

        private void btback_Click(object sender, EventArgs e)
        {
            this.Close();
            try
            {
                this.Dispose(true);
            }
            catch (Exception ex)
            {
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }
        }

        private async void btsave_Click(object sender, EventArgs e)
        {
            if(site != null)
            {
                int result = await siteDAO.UpdateSiteById(site.Id, txtUrl.Text, Convert.ToInt32(numOrderDissection.Value));
                siteDAO.Dispose();
                if (result == 1)
                {
                    string message = "Sửa thông tin Preview thành công!";
                    string noti = "Thông báo";
                    MessageBoxButtons buttons = MessageBoxButtons.OK;
                    DialogResult resultUpdate = MessageBox.Show(message, noti, buttons);
                    if (resultUpdate == DialogResult.OK)
                    {
                        this.Close();
                        try
                        {
                            this.Dispose(true);
                        }
                        catch (Exception ex)
                        {
                            var type = this.GetType().Name;
                            Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
                        }
                    }
                }
                else
                {
                    string message = "Sửa thông tin Preview thất bại!";
                    string noti = "Thông báo";
                    MessageBoxButtons buttons = MessageBoxButtons.OK;
                    DialogResult resultUpdate = MessageBox.Show(message, noti, buttons);
                }
            }
        }

        private void FrmEditPriviewAdmin_FormClosed(object sender, FormClosedEventArgs e)
        {
            frmAdmin frm = Application.OpenForms.OfType<frmAdmin>().FirstOrDefault();
            if (frm != null)
            {
                frm.LoadData();
                //frm.HandleButtonEdit();
            }
        }
    }
}
