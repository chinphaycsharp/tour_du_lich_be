﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using VCCorp.PreviewCore.Common;
using VCCorp.PreviewCore.DAO;
using VCCorp.PreviewCore.DTO;
using VCCorp.PreviewVer2.Common;

namespace VCCorp.PreviewVer2
{
    public partial class frmBotCrawler : Form
    {
        private readonly SiteDAO siteDAO = null;
        private readonly PreviewResultDAO previewResultDAO = null;
        private List<SiteDTO> dataUrl = new List<SiteDTO>();
        private int siteCount = 0;
        private string UrlPreview = "";
        private List<int> status = new List<int>() { 0 };
        //private int countFrm = 0;
        public frmBotCrawler()
        {
            InitializeComponent();
            try
            {
                timeAutoOpenForm.Start();
            }
            catch (Exception ex)
            {
                string err = ex.Message;
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }
            siteDAO = new SiteDAO(ConnectionDAO.ConnectionToTableLinkProduct);
            previewResultDAO = new PreviewResultDAO(ConnectionDAO.ConnectionToTableLinkProduct);
            btnTest.Enabled = false;
            LoadData();
        }

        public void LoadData()
        {
            gridPriview.Rows.Clear();
            siteCount = previewResultDAO.GetLimitPreview("192.168.1.199", status).Count;
            if (siteCount > 0)
            {
                dataUrl = previewResultDAO.GetLimitPreview("192.168.1.199", status);
                previewResultDAO.Dispose();
            }
            else
            {
                dataUrl = siteDAO.GetSitesLimit(status);
                siteDAO.Dispose();
            }

            if (dataUrl.Count > 0)
            {
                string message = "";
                try
                {
                    foreach (var item in dataUrl)
                    {
                        DataGridViewRow newRow = new DataGridViewRow();
                        newRow.CreateCells(gridPriview);
                        newRow.Cells[0].Value = item.Id;
                        newRow.Cells[1].Value = item.Url;
                        newRow.Cells[2].Value = item.CreatedDateStr;
                        newRow.Cells[3].Value = item.CrawlDateStr;
                        newRow.Cells[4].Value = item.StatusStr;
                        newRow.Cells[5].Value = item.OrderDissection;
                        gridPriview.Rows.Add(newRow);
                    }
                }
                catch (Exception ex)
                {
                    message = ex.Message;
                    var type = this.GetType().Name;
                    Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
                }
            }
            else
            {
                string message = "Không có trang Priviews trong hệ thống! Hãy thêm mới.";
                string noti = "Thông báo";
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                DialogResult result = MessageBox.Show(message, noti, buttons);
            }
        }


        private async void btnTest_Click(object sender, EventArgs e)
        {
            if (txtUrl.Text != "")
            {
                bool check = await TestDownloadHtml(txtUrl.Text);
                if (check)
                {
                    string message = "";
                    string noti = "Thông báo";
                    MessageBoxButtons buttons = MessageBoxButtons.OK;
                    if (check == true)
                    {
                        message = "Test Download Html thành công!";
                        DialogResult result = MessageBox.Show(message, noti, buttons);
                    }
                    else
                    {
                        message = "Test Download Html thất bại!";
                        DialogResult result = MessageBox.Show(message, noti, buttons);
                    }
                }
            }
        }

        private void gridPriview_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                btnTest.Enabled = true;
                try
                {
                    DataGridViewRow row = gridPriview.SelectedRows[0];
                    UrlPreview = row.Cells[1].Value.ToString();
                    txtUrl.Text = UrlPreview;
                }
                catch (Exception ex)
                {
                    string message = ex.Message;
                    var type = this.GetType().Name;
                    Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
                }
            }
        }

        public async Task<bool> TestDownloadHtml(string url)
        {
            bool check = false;
            if (url != "")
            {
                try
                {
                    check = await Utilities.TestDownloadHTML(url);
                }
                catch (Exception ex)
                {
                    string mess = ex.Message;
                    var type = this.GetType().Name;
                    Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
                }
            }
            return check;
        }

        private void btLoad_Click(object sender, EventArgs e)
        {
            LoadData();
        }

        private async void btnOpen_Click(object sender, EventArgs e)
        {
            await OpenFormCrawl();
        }

        private void btAgainDissection_Click(object sender, EventArgs e)
        {
            status.Add(1);
            LoadData();
        }

        //300000
        private async void timeAutoOpenForm_Tick(object sender, EventArgs e)
        {
            DateTime now = DateTime.Now;
            if (now.Hour == 0 && now.Minute > 15)
            {
                await OpenFormCrawl();
            }
            if (ListNameFrm.listNameFrms.Count < 5)
            {
                await OpenFormCrawl();
            }
        }

        public async Task OpenFormCrawl()
        {
            LoadData();
            if (dataUrl.Count > 0)
            {
                for (int i = 0; i < dataUrl.Count; i++)
                {
                    if (ListNameFrm.listNameFrms.Count == 5)
                    {
                        break;
                    }
                    int newIndex = (i + dataUrl.Count) % dataUrl.Count; // Tính vị trí mới của phần tử
                    var newElement = dataUrl[newIndex]; // Lấy phần tử ở vị trí mới
                                                        //var site = dataUrl.FirstOrDefault(x => x.Url == newElement.Url);
                    var frmResult = ListFrm.listFrms.FirstOrDefault(x => x.Url == dataUrl[i].Url);
                    var check = ListNameFrm.listNameFrms.FirstOrDefault(x => x == dataUrl[i].Url);
                    if (check == null && ListNameFrm.countFrm < 5) // Kiểm tra phần tử có trong danh sách mới hay chưa
                    {
                        // Thêm vào danh sách mới
                        ListNameFrm.listNameFrms.Add(dataUrl[i].Url);
                        dynamic instance = Utilities.GetClassFromString(frmResult.frm, dataUrl[i].Url, dataUrl[i].Id);
                        if (Application.OpenForms[frmResult.frm] != null)
                        {
                            //instance.BringToFront();
                        }
                        else
                        {
                            instance.Show(); //Class1 does special things
                        }
                        ListNameFrm.countFrm++;
                    }
                    await Task.Delay(2_000);
                }
            }
        }

        private async void frmBotCrawler_Load(object sender, EventArgs e)
        {
            await Task.Delay(TimeSpan.FromSeconds(2));
            await OpenFormCrawl();
        }
    }
}
