﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using VCCorp.PreviewCore.Common;
using VCCorp.PreviewCore.DAO;
using VCCorp.PreviewCore.DTO;

namespace VCCorp.PreviewVer2.FrmAdmin
{
    public partial class FrmAddPriviewAdmin : Form
    {
        private readonly SiteDAO siteDAO = null;
        public FrmAddPriviewAdmin()
        {
            InitializeComponent();
            siteDAO = new SiteDAO(ConnectionDAO.ConnectionToTableLinkProduct);
        }

        private void btBack_Click(object sender, EventArgs e)
        {
            this.Close();
            try
            {
                this.Dispose(true);
            }
            catch(Exception ex)
            {
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }
        }

        private async void btAddSite_Click(object sender, EventArgs e)
        {
            if(txtUrl.Text == "")
            {
                string message = "URL không được để chống!";
                string noti = "Thông báo";
                MessageBoxButtons buttons = MessageBoxButtons.OK;
                DialogResult addBox = MessageBox.Show(message, noti, buttons);
            }
            else
            {
                int exist = siteDAO.GetSiteByLink(txtUrl.Text);
                siteDAO.Dispose();
                if (exist == 0)
                {
                    SiteDTO dto = new SiteDTO();
                    dto.Url = txtUrl.Text;
                    dto.CreatedDate = DateTime.Now;
                    dto.OrderDissection = Convert.ToInt32(numOrderDissection.Value);
                    int result = 0;
                    try
                    {
                        result = await siteDAO.InsertSite(dto);
                        siteDAO.Dispose();
                        string message = "Thêm trang Preview thành công!";
                        string noti = "Thông báo";
                        MessageBoxButtons buttons = MessageBoxButtons.OK;
                        DialogResult addBox = MessageBox.Show(message, noti, buttons);
                    }
                    catch (Exception ex)
                    {
                        var type = this.GetType().Name;
                        Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
                    }
                    finally
                    {
                        this.Close();
                        try
                        {
                            this.Dispose(true);
                        }
                        catch(Exception ex)
                        {
                            var type = this.GetType().Name;
                            Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
                        }
                    }
                }
                else
                {
                    string message = "URL đã tồn tại trong hệ thống vui lòng kiểm tra lại!";
                    string noti = "Thông báo";
                    MessageBoxButtons buttons = MessageBoxButtons.OK;
                    DialogResult addBox = MessageBox.Show(message, noti, buttons);
                }
            }
        }

        /// <summary>
        /// Refresh data form manager admin after form add prview will be close
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// <returns></returns>
        private void FrmAddPriviewAdmin_FormClosed(object sender, FormClosedEventArgs e)
        {
            frmAdmin frm = Application.OpenForms.OfType<frmAdmin>().FirstOrDefault();
            if (frm != null)
            {
                frm.LoadData();
            }
        }
    }
}
