﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using VCCorp.PreviewCore.DAO;
using VCCorp.PreviewCore.DTO;

namespace VCCorp.PreviewVer2.FrmBot
{
    public partial class frmCrawlerDissectedBot : Form
    {
        private readonly SiteDAO siteDAO = null;
        private readonly PreviewResultDAO previewResultDAO = null;
        private int siteCount = 0;
        private List<int> status = new List<int>() { 0 };
        public frmCrawlerDissectedBot()
        {
            InitializeComponent();
            siteDAO = new SiteDAO(ConnectionDAO.ConnectionToTableLinkProduct);
            previewResultDAO = new PreviewResultDAO(ConnectionDAO.ConnectionToTableLinkProduct);
            LoadData();
        }

        public async void LoadData()
        {
            await Task.Delay(1_000);
            gridPriview.Rows.Clear();
            List<SiteDTO> dataUrl = new List<SiteDTO>();
            siteCount = previewResultDAO.GetLimitPreview("192.168.1.199",status).Count;
            if(siteCount > 0)
            {
                dataUrl = previewResultDAO.GetLimitPreview("192.168.1.199",status);
                previewResultDAO.Dispose();
            }
            else
            {
                dataUrl = siteDAO.GetSitesLimit(status);
                siteDAO.Dispose();
            }
            
            if (dataUrl.Count > 0)
            {
                string message = "";
                try
                {
                    foreach (var item in dataUrl)
                    {
                        DataGridViewRow newRow = new DataGridViewRow();
                        newRow.CreateCells(gridPriview);
                        newRow.Cells[0].Value = item.Id;
                        newRow.Cells[1].Value = item.Url; 
                        newRow.Cells[2].Value = item.CreatedDateStr;
                        newRow.Cells[3].Value = item.CrawlDateStr;
                        newRow.Cells[4].Value = item.OrderDissection;
                        newRow.Cells[5].Value = item.StatusStr;
                        gridPriview.Rows.Add(newRow);
                    }
                }
                catch (Exception ex)
                {
                    message = ex.Message;
                }
            }
            else
            {
                string message = "Không có trang Priviews trong hệ thống! Hãy thêm mới.";
                string noti = "Thông báo";
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                DialogResult result = MessageBox.Show(message, noti, buttons);
            }
        }
    }
}
