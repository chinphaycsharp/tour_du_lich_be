﻿using CefSharp.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using VCCorp.PreviewCore.BUS;
using VCCorp.PreviewCore.Common;
using VCCorp.PreviewCore.DAO;
using VCCorp.PreviewCore.DTO;

namespace VCCorp.PreviewVer2.FrmBot
{
    public partial class frmDissectedResultBot : Form
    {
        private ChromiumWebBrowser browser;
        private Control control;
        private readonly CategoryDAO categoryDAO = null;
        private List<CategoryDTO> dataUrl = new List<CategoryDTO>();
        private int SiteId = 0;
        private string domainUrl = "";
        public frmDissectedResultBot(string url,int id)
        {
            InitializeComponent();
            control = rtbResult;
            categoryDAO = new CategoryDAO(ConnectionDAO.ConnectionToTableLinkProduct);
            this.Text = $"Kết quả bóc tách trang {url.ToUpper()}";
            Utilities.WriteLogToTxtFile($"Bóc tách trang {url.ToUpper()}");
            txtUrl.Text = url;
            domainUrl = url;
            SiteId = id;
            LoadData();
            WriteToBoxResult($"Bắt đầu bóc tại trang {url} tại chuyên mục {dataUrl[0].Description.ToUpper()}");
        }

        public async void LoadData()
        {
            dataUrl = categoryDAO.GetSiteBySiteId(SiteId);
            if (dataUrl.Count > 0)
            {

            }
            else
            {
                string message = "Không có trang Priviews trong hệ thống! Hãy thêm mới.";
                string noti = "Thông báo";
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                DialogResult result = MessageBox.Show(message, noti, buttons);
            }
            await Task.Delay(2_000);
        }

        private void WriteToBoxResult(string text)
        {
            if (this.IsHandleCreated)
            {
                control.BeginInvoke((MethodInvoker)delegate ()
                {
                    if (dataUrl.Count > 0)
                    {
                        rtbResult.AppendText(text + Environment.NewLine + Environment.NewLine);
                    }
                });
            }
            else
            {
                rtbResult.AppendText(text + Environment.NewLine + Environment.NewLine);
            }
        }

        private void btnRun_Click(object sender, EventArgs e)
        {
            if(dataUrl.Count > 0)
            {
                //ParserAgoda parser = new ParserAgoda(browser);
                //await parser.CrawlData(dataUrl);
            }
        }
    }
}
