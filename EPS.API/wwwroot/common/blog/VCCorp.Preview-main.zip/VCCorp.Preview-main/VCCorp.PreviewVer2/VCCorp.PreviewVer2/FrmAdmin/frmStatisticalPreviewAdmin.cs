﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using VCCorp.PreviewCore.Common;
using VCCorp.PreviewCore.DAO;
using VCCorp.PreviewCore.DTO;

namespace VCCorp.PreviewVer2.FrmAdmin
{
    public partial class frmStatisticalPreviewAdmin : Form
    {
        private readonly ArticleDAO articleDAO = null;
        private string _Url = "";
        private int siteCount = 0;
        public frmStatisticalPreviewAdmin()
        {
            InitializeComponent();
            articleDAO = new ArticleDAO(ConnectionDAO.ConnectionToTableLinkProduct);
            AddDataToComboBox();
            LoadData(-1);
        }

        public void LoadData(int day)
        {
            dataGridView1.Rows.Clear();
            List<ArticleDTO> dataUrl = articleDAO.StastisticArticles(day);
            articleDAO.Dispose();
            siteCount = dataUrl.Count;
            if (dataUrl.Count > 0)
            {
                lblCount.Text = siteCount.ToString();
                string message = "";
                try
                {
                    foreach (var item in dataUrl)
                    {
                        DataGridViewRow newRow = new DataGridViewRow();
                        newRow.CreateCells(dataGridView1);
                        newRow.Cells[0].Value = item.Id;
                        newRow.Cells[1].Value = item.Url;
                        newRow.Cells[2].Value = item.DomainName;
                        newRow.Cells[3].Value = item.Title;
                        newRow.Cells[4].Value = item.CreatedDateStr;
                        newRow.Cells[5].Value = item.SendDateStr;
                        newRow.Cells[6].Value = item.StatusStr;
                        newRow.Cells[7].Value = item.CategoryId;
                        dataGridView1.Rows.Add(newRow);
                    }
                }
                catch (Exception ex)
                {
                    message = ex.Message;
                    var type = this.GetType().Name;
                    Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
                }
            }
            else
            {
                lblCount.Text = siteCount.ToString();
                string message = "Không có trang bản viết nào được bóc!";
                string noti = "Thông báo";
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                DialogResult result = MessageBox.Show(message, noti, buttons);
            }
        }

        private void AddDataToComboBox()
        {
            foreach (var item in DayStatisticDTO.days)
            {
                cboStatistic.Items.Add(item.Text);
            }
            cboStatistic.SelectedIndex = 0;
        }

        private void btStatistic_Click(object sender, EventArgs e)
        {
            string selectItem = cboStatistic.SelectedItem.ToString();
            var result = DayStatisticDTO.days.FirstOrDefault(x => x.Text == selectItem);
            if(result != null)
            {
                LoadData(result.Value);
            }
            else
            {
                string message = "Không có dữ liệu nào phù hợp.";
                string noti = "Thông báo";
                MessageBoxButtons buttons = MessageBoxButtons.OK;
                DialogResult error = MessageBox.Show(message, noti, buttons);
            }
        }
    }
}
