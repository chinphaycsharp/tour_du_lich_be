﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Windows.Forms;
using VCCorp.PreviewCore.DAO;
using VCCorp.PreviewCore.DTO;

namespace VCCorp.PreviewVer2.FrmPriview
{
    public partial class frm_si_crawl_data_excel : Form
    {
        private readonly Si_Crawl_Data_Excel_DAO _si_Crawl_Data_Excel_DAO = null;
        private List<Si_Crawl_Data_ExcelDTO> si_Crawl_Data_Excels = null;
        public frm_si_crawl_data_excel()
        {
            InitializeComponent();
            _si_Crawl_Data_Excel_DAO = new Si_Crawl_Data_Excel_DAO(ConnectionDAO.ConnectionToTableLinkServer);
        }

        private async void AutoCrawlData_Tick(object sender, EventArgs e)
        {
            si_Crawl_Data_Excels = _si_Crawl_Data_Excel_DAO.GetAllSiCrawlDataExcel("preview");
            if(si_Crawl_Data_Excels.Count > 0)
            {
                foreach (var item in si_Crawl_Data_Excels)
                {

                }
            }
            await Task.Delay(TimeSpan.FromMinutes(5));
        }
    }
}
