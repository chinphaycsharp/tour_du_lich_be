﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VCCorp.PreviewVer2.FrmBot
{
    public partial class frmDissectedCefSharpResultBot : Form
    {
        private int _categoryId = 0;
        public frmDissectedCefSharpResultBot(string url, int categoryId)
        {
            InitializeComponent();
            txtUrl.Text = url;
            _categoryId = categoryId;
        }
    }
}
