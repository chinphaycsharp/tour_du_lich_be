﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using VCCorp.PreviewCore.Common;
using VCCorp.PreviewCore.DAO;
using VCCorp.PreviewCore.DTO;
using VCCorp.PreviewVer2.FrmAdmin;

namespace VCCorp.PreviewVer2
{
    public partial class frmAdmin : Form
    {
        private readonly SiteDAO siteDAO = null;
        private SiteDTO site = null;
        private int siteCount = 0;
        public frmAdmin()
        {
            InitializeComponent();
            HandleButtonEdit();
            HandleButtonDelete();
            HandleButtonManageCategory();
            siteDAO = new SiteDAO(ConnectionDAO.ConnectionToTableLinkProduct);
            LoadData();
        }

        public void HandleButtonEdit()
        {
            btEdit.Enabled = !btEdit.Enabled;
        }

        public void HandleButtonDelete()
        {
            btDelete.Enabled = !btDelete.Enabled;
        }

        public void HandleButtonManageCategory()
        {
            btCategory.Enabled = !btCategory.Enabled;
        }

        private void btLoadData_Click(object sender, EventArgs e)
        {
            LoadData();
        }

        public async void LoadData()
        {
            await Task.Delay(1_000);
            dataGridView1.Rows.Clear();
            List<SiteDTO> dataUrl = siteDAO.GetAllSites();
            siteDAO.Dispose();
            siteCount = dataUrl.Count;
            if(dataUrl.Count > 0)
            {
                string message = "";
                try
                {
                    foreach (var item in dataUrl)
                    {
                        DataGridViewRow newRow = new DataGridViewRow();
                        newRow.CreateCells(dataGridView1);
                        newRow.Cells[0].Value = item.Id;
                        newRow.Cells[1].Value = item.Url;
                        newRow.Cells[2].Value = item.CreatedDateStr;
                        newRow.Cells[3].Value = item.CrawlDateStr;
                        newRow.Cells[4].Value = item.OrderDissection;
                        newRow.Cells[5].Value = item.StatusStr;
                        dataGridView1.Rows.Add(newRow);
                    }
                }
                catch(Exception ex)
                {
                    message = ex.Message;
                    var type = this.GetType().Name;
                    Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
                }
            }
            else
            {
                string message = "Không có trang Priviews trong hệ thống! Hãy thêm mới.";
                string noti = "Thông báo";
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                DialogResult result = MessageBox.Show(message, noti, buttons);
                if (result == DialogResult.Yes)
                {
                    FrmAddPriviewAdmin frm = new FrmAddPriviewAdmin();
                    frm.Show();
                }
                else
                {
                    // Do something  
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            btEdit.Enabled = false;
            btDelete.Enabled = false;
            btCategory.Enabled = false;
            FrmAddPriviewAdmin frm = new FrmAddPriviewAdmin();
            frm.Show();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                btEdit.Enabled = true;
                btDelete.Enabled = true;
                btCategory.Enabled = true;
                try
                {
                    DataGridViewRow row = dataGridView1.SelectedRows[0];
                    int Id = Convert.ToInt32(row.Cells[0].Value);
                    if (Id > 0)
                    {
                        site = siteDAO.GetSiteById(Id);
                        siteDAO.Dispose();
                    }
                }
                catch(Exception ex)
                {
                    string message = ex.Message;
                    var type = this.GetType().Name;
                    Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
                }
            }
        }

        private void btEdit_Click(object sender, EventArgs e)
        {
            if(site != null)
            {
                btEdit.Enabled = false;
                btDelete.Enabled = false;
                FrmEditPriviewAdmin frm = new FrmEditPriviewAdmin(site);
                frm.Show();
            }
        }

        private void btStatistical_Click(object sender, EventArgs e)
        {
            frmStatisticalPreviewAdmin frm = new frmStatisticalPreviewAdmin();
            frm.Show();
        }

        private void btCategory_Click(object sender, EventArgs e)
        {
            if(site != null)
            {
                frmManageCategoryAdmin frm = new frmManageCategoryAdmin(site);
                frm.Show();
            }
        }
        
        private async void btDelete_Click(object sender, EventArgs e)
        {
            if (site != null)
            {

                int resultDelete = await siteDAO.DeleteSiteById(site.Id);
                siteDAO.Dispose();
                string message = "";
                string noti = "Thông báo";
                MessageBoxButtons buttons = MessageBoxButtons.OK;
                if (resultDelete == 1)
                {
                    message = "Xóa thành công!";
                    DialogResult result = MessageBox.Show(message, noti, buttons);
                }
                else
                {
                    message = "Xóa thất bại!";
                    DialogResult result = MessageBox.Show(message, noti, buttons);
                }
                btDelete.Enabled = false;
                btEdit.Enabled = false;
                LoadData();
            }
        }

        private void btDissection_Click(object sender, EventArgs e)
        {

        }

        private void btAuto_Click(object sender, EventArgs e)
        {
            
        }
    }
}
