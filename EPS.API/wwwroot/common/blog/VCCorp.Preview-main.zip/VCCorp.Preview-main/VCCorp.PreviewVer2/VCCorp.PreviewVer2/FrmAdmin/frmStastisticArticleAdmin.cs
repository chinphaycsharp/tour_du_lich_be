﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VCCorp.PreviewVer2.FrmAdmin
{
    public partial class frmStastisticArticleAdmin : Form
    {
        public frmStastisticArticleAdmin()
        {
            InitializeComponent();
        }
    }
}
