﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using VCCorp.PreviewCore.Common;
using VCCorp.PreviewCore.DAO;
using VCCorp.PreviewCore.DTO;

namespace VCCorp.PreviewVer2.FrmAdmin
{
    public partial class frmAddCategoryAdmin : Form
    {
        private readonly CategoryDAO categoryDAO = null;
        public int _siteId;
        public string _domain;
        public frmAddCategoryAdmin(int siteId,string domain)
        {
            InitializeComponent();
            categoryDAO = new CategoryDAO(ConnectionDAO.ConnectionToTableLinkProduct);
            _siteId = siteId;
            txtDomain.Enabled = false;
            txtDomain.Text = domain;
        }

        private void btBack_Click(object sender, EventArgs e)
        {
            this.Close();
            try
            {
                this.Dispose(true);
            }
            catch(Exception ex)
            {
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }
        }

        private async void btnSave_Click(object sender, EventArgs e)
        {
            if (txtUrl.Text == "")
            {
                string message = "URL không được để chống!";
                string noti = "Thông báo";
                MessageBoxButtons buttons = MessageBoxButtons.OK;
                DialogResult addBox = MessageBox.Show(message, noti, buttons);
            }
            else
            {
                int exist = categoryDAO.GetCategoryByLink(txtUrl.Text);
                categoryDAO.Dispose();
                if (exist == 0)
                {
                    CategoryDTO dto = new CategoryDTO();
                    dto.Url = txtUrl.Text;
                    dto.CreatedDate = DateTime.Now;
                    dto.SiteId = _siteId;
                    dto.Description = txtDescription.Text;
                    int result = 0;
                    try
                    {
                        result = await categoryDAO.InsertCategory(dto);
                        categoryDAO.Dispose();
                        string message = "Thêm chuyên mục thành công thành công!";
                        string noti = "Thông báo";
                        MessageBoxButtons buttons = MessageBoxButtons.OK;
                        DialogResult addBox = MessageBox.Show(message, noti, buttons);
                    }
                    catch (Exception ex)
                    {
                        var type = this.GetType().Name;
                        Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
                    }
                    finally
                    {
                        this.Close();
                        try
                        {
                            this.Dispose(true);
                        }
                        catch(Exception ex)
                        {
                            var type = this.GetType().Name;
                            Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
                        }
                    }
                }
                else
                {
                    string message = "URL đã tồn tại trong hệ thống vui lòng kiểm tra lại!";
                    string noti = "Thông báo";
                    MessageBoxButtons buttons = MessageBoxButtons.OK;
                    DialogResult addBox = MessageBox.Show(message, noti, buttons);
                }
            }
        }

        private void frmAddCategoryAdmin_FormClosed(object sender, FormClosedEventArgs e)
        {
            frmManageCategoryAdmin frm = Application.OpenForms.OfType<frmManageCategoryAdmin>().FirstOrDefault();
            if (frm != null)
            {
                frm.LoadData();
            }
        }
    }
}
