﻿
namespace VCCorp.PreviewVer2.FrmAdmin
{
    partial class frmManageCategoryAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button7 = new System.Windows.Forms.Button();
            this.btEdit = new System.Windows.Forms.Button();
            this.btDelete = new System.Windows.Forms.Button();
            this.btAdd = new System.Windows.Forms.Button();
            this.btShowDetail = new System.Windows.Forms.Button();
            this.lblCategoryError = new System.Windows.Forms.Label();
            this.lblCategoryDissected = new System.Windows.Forms.Label();
            this.lblCategoryUndissected = new System.Windows.Forms.Label();
            this.lblCategoryAll = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtUrl = new System.Windows.Forms.TextBox();
            this.gridCategories = new System.Windows.Forms.DataGridView();
            this.Id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Url = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Domain = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Description = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CreatedDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SendDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridCategories)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button7);
            this.groupBox1.Controls.Add(this.btEdit);
            this.groupBox1.Controls.Add(this.btDelete);
            this.groupBox1.Controls.Add(this.btAdd);
            this.groupBox1.Controls.Add(this.btShowDetail);
            this.groupBox1.Controls.Add(this.lblCategoryError);
            this.groupBox1.Controls.Add(this.lblCategoryDissected);
            this.groupBox1.Controls.Add(this.lblCategoryUndissected);
            this.groupBox1.Controls.Add(this.lblCategoryAll);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtUrl);
            this.groupBox1.Controls.Add(this.gridCategories);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1251, 615);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Danh sách chuyên mục";
            // 
            // button7
            // 
            this.button7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button7.Location = new System.Drawing.Point(671, 86);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(149, 25);
            this.button7.TabIndex = 16;
            this.button7.Text = "Load chuyên mục";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // btEdit
            // 
            this.btEdit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btEdit.Location = new System.Drawing.Point(981, 86);
            this.btEdit.Name = "btEdit";
            this.btEdit.Size = new System.Drawing.Size(136, 25);
            this.btEdit.TabIndex = 15;
            this.btEdit.Text = "Sửa chuyên mục";
            this.btEdit.UseVisualStyleBackColor = true;
            this.btEdit.Click += new System.EventHandler(this.btEdit_Click);
            // 
            // btDelete
            // 
            this.btDelete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btDelete.Location = new System.Drawing.Point(1123, 86);
            this.btDelete.Name = "btDelete";
            this.btDelete.Size = new System.Drawing.Size(122, 25);
            this.btDelete.TabIndex = 14;
            this.btDelete.Text = "Xóa chuyên mục";
            this.btDelete.UseVisualStyleBackColor = true;
            this.btDelete.Click += new System.EventHandler(this.btDelete_Click);
            // 
            // btAdd
            // 
            this.btAdd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btAdd.Location = new System.Drawing.Point(826, 86);
            this.btAdd.Name = "btAdd";
            this.btAdd.Size = new System.Drawing.Size(149, 25);
            this.btAdd.TabIndex = 13;
            this.btAdd.Text = "Thêm chuyên mục";
            this.btAdd.UseVisualStyleBackColor = true;
            this.btAdd.Click += new System.EventHandler(this.btAdd_Click);
            // 
            // btShowDetail
            // 
            this.btShowDetail.Location = new System.Drawing.Point(355, 21);
            this.btShowDetail.Name = "btShowDetail";
            this.btShowDetail.Size = new System.Drawing.Size(122, 25);
            this.btShowDetail.TabIndex = 12;
            this.btShowDetail.Text = "Xem chi tiết";
            this.btShowDetail.UseVisualStyleBackColor = true;
            // 
            // lblCategoryError
            // 
            this.lblCategoryError.AutoSize = true;
            this.lblCategoryError.Location = new System.Drawing.Point(352, 90);
            this.lblCategoryError.Name = "lblCategoryError";
            this.lblCategoryError.Size = new System.Drawing.Size(15, 16);
            this.lblCategoryError.TabIndex = 11;
            this.lblCategoryError.Text = "0";
            // 
            // lblCategoryDissected
            // 
            this.lblCategoryDissected.AutoSize = true;
            this.lblCategoryDissected.Location = new System.Drawing.Point(161, 90);
            this.lblCategoryDissected.Name = "lblCategoryDissected";
            this.lblCategoryDissected.Size = new System.Drawing.Size(15, 16);
            this.lblCategoryDissected.TabIndex = 10;
            this.lblCategoryDissected.Text = "0";
            // 
            // lblCategoryUndissected
            // 
            this.lblCategoryUndissected.AutoSize = true;
            this.lblCategoryUndissected.Location = new System.Drawing.Point(352, 60);
            this.lblCategoryUndissected.Name = "lblCategoryUndissected";
            this.lblCategoryUndissected.Size = new System.Drawing.Size(15, 16);
            this.lblCategoryUndissected.TabIndex = 9;
            this.lblCategoryUndissected.Text = "0";
            // 
            // lblCategoryAll
            // 
            this.lblCategoryAll.AutoSize = true;
            this.lblCategoryAll.Location = new System.Drawing.Point(161, 60);
            this.lblCategoryAll.Name = "lblCategoryAll";
            this.lblCategoryAll.Size = new System.Drawing.Size(15, 16);
            this.lblCategoryAll.TabIndex = 8;
            this.lblCategoryAll.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label4.Location = new System.Drawing.Point(207, 60);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(142, 16);
            this.label4.TabIndex = 7;
            this.label4.Text = "Chuyên mục chưa bóc:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(207, 90);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(101, 16);
            this.label3.TabIndex = 6;
            this.label3.Text = "Chuyên mục lỗi:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label2.Location = new System.Drawing.Point(8, 90);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(147, 16);
            this.label2.TabIndex = 5;
            this.label2.Text = "Số chuyên mục đã bóc:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(117, 16);
            this.label1.TabIndex = 4;
            this.label1.Text = "Tổng chuyên mục:";
            // 
            // txtUrl
            // 
            this.txtUrl.Location = new System.Drawing.Point(6, 22);
            this.txtUrl.Name = "txtUrl";
            this.txtUrl.Size = new System.Drawing.Size(343, 22);
            this.txtUrl.TabIndex = 1;
            // 
            // gridCategories
            // 
            this.gridCategories.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gridCategories.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gridCategories.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridCategories.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Id,
            this.Url,
            this.Domain,
            this.Description,
            this.CreatedDate,
            this.SendDate,
            this.Status});
            this.gridCategories.Location = new System.Drawing.Point(6, 117);
            this.gridCategories.Name = "gridCategories";
            this.gridCategories.Size = new System.Drawing.Size(1239, 492);
            this.gridCategories.TabIndex = 0;
            this.gridCategories.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridCategories_CellClick);
            // 
            // Id
            // 
            this.Id.HeaderText = "Id";
            this.Id.Name = "Id";
            this.Id.Visible = false;
            // 
            // Url
            // 
            this.Url.FillWeight = 146.5416F;
            this.Url.HeaderText = "Url";
            this.Url.Name = "Url";
            this.Url.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // Domain
            // 
            this.Domain.FillWeight = 110.4283F;
            this.Domain.HeaderText = "Domain";
            this.Domain.Name = "Domain";
            // 
            // Description
            // 
            this.Description.HeaderText = "Mô tả";
            this.Description.Name = "Description";
            // 
            // CreatedDate
            // 
            this.CreatedDate.FillWeight = 67.69177F;
            this.CreatedDate.HeaderText = "Ngày tạo";
            this.CreatedDate.Name = "CreatedDate";
            // 
            // SendDate
            // 
            this.SendDate.FillWeight = 74.691F;
            this.SendDate.HeaderText = "Ngày gửi";
            this.SendDate.Name = "SendDate";
            // 
            // Status
            // 
            this.Status.FillWeight = 100.6473F;
            this.Status.HeaderText = "Trạng thái";
            this.Status.Name = "Status";
            // 
            // frmManageCategoryAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1251, 615);
            this.Controls.Add(this.groupBox1);
            this.Name = "frmManageCategoryAdmin";
            this.Text = "Quản lý chuyên mục";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridCategories)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView gridCategories;
        private System.Windows.Forms.TextBox txtUrl;
        private System.Windows.Forms.Label lblCategoryError;
        private System.Windows.Forms.Label lblCategoryDissected;
        private System.Windows.Forms.Label lblCategoryUndissected;
        private System.Windows.Forms.Label lblCategoryAll;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btShowDetail;
        private System.Windows.Forms.Button btEdit;
        private System.Windows.Forms.Button btDelete;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button btAdd;
        private System.Windows.Forms.DataGridViewTextBoxColumn Id;
        private System.Windows.Forms.DataGridViewTextBoxColumn Url;
        private System.Windows.Forms.DataGridViewTextBoxColumn Domain;
        private System.Windows.Forms.DataGridViewTextBoxColumn Description;
        private System.Windows.Forms.DataGridViewTextBoxColumn CreatedDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn SendDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Status;
    }
}