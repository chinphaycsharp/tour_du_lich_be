﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VCCorp.PreviewVer2
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
            autoCloseApp.Start();
        }

        private void btAdmin_Click(object sender, EventArgs e)
        {
            frmAdmin frm = new frmAdmin();
            if (Application.OpenForms["frmAdmin"] != null)
            {
                frm.BringToFront();
            }
            else
            {
                frm.Show();
            }
        }

        private void btBotCrawler_Click(object sender, EventArgs e)
        {
            frmBotCrawler frm = new frmBotCrawler();
            if (Application.OpenForms["frmBotCrawler"] != null)
            {
                //frm.BringToFront();
            }
            else
            {
                frm.Show();
            }

        }

        private async void autoCloseApp_Tick(object sender, EventArgs e)
        {
            //Application.Exit();
            await Task.Delay(TimeSpan.FromSeconds(2));
            frmBotCrawler frm = new frmBotCrawler();
            if (Application.OpenForms["frmBotCrawler"] != null)
            {
                //frm.BringToFront();
            }
            else
            {
                frm.Show();
            }
        }

        private async void frmMain_Load(object sender, EventArgs e)
        {
            await Task.Delay(TimeSpan.FromSeconds(2));
            frmBotCrawler frm = new frmBotCrawler();
            if (Application.OpenForms["frmBotCrawler"] != null)
            {
                frm.BringToFront();
            }
            else
            {
                frm.Show();
            }
        }
    }
}
