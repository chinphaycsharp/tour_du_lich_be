﻿
namespace VCCorp.PreviewVer2
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.grpChoise = new System.Windows.Forms.GroupBox();
            this.btBotCrawler = new System.Windows.Forms.Button();
            this.btAdmin = new System.Windows.Forms.Button();
            this.autoCloseApp = new System.Windows.Forms.Timer(this.components);
            this.grpChoise.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpChoise
            // 
            this.grpChoise.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.grpChoise.Controls.Add(this.btBotCrawler);
            this.grpChoise.Controls.Add(this.btAdmin);
            this.grpChoise.Location = new System.Drawing.Point(12, 55);
            this.grpChoise.Name = "grpChoise";
            this.grpChoise.Size = new System.Drawing.Size(703, 346);
            this.grpChoise.TabIndex = 0;
            this.grpChoise.TabStop = false;
            this.grpChoise.Text = "Chọn Chức Năng";
            // 
            // btBotCrawler
            // 
            this.btBotCrawler.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btBotCrawler.Location = new System.Drawing.Point(383, 119);
            this.btBotCrawler.Name = "btBotCrawler";
            this.btBotCrawler.Size = new System.Drawing.Size(272, 70);
            this.btBotCrawler.TabIndex = 1;
            this.btBotCrawler.Text = "BOT CRAWLER";
            this.btBotCrawler.UseVisualStyleBackColor = true;
            this.btBotCrawler.Click += new System.EventHandler(this.btBotCrawler_Click);
            // 
            // btAdmin
            // 
            this.btAdmin.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btAdmin.Location = new System.Drawing.Point(60, 119);
            this.btAdmin.Name = "btAdmin";
            this.btAdmin.Size = new System.Drawing.Size(272, 70);
            this.btAdmin.TabIndex = 0;
            this.btAdmin.Text = "PHẦN ADMIN";
            this.btAdmin.UseVisualStyleBackColor = true;
            this.btAdmin.Click += new System.EventHandler(this.btAdmin_Click);
            // 
            // autoCloseApp
            // 
            this.autoCloseApp.Interval = 4000;
            this.autoCloseApp.Tick += new System.EventHandler(this.autoCloseApp_Tick);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(732, 450);
            this.Controls.Add(this.grpChoise);
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Hệ Thống Bóc Tách Các Trang PREVIEW";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.grpChoise.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpChoise;
        private System.Windows.Forms.Button btBotCrawler;
        private System.Windows.Forms.Button btAdmin;
        private System.Windows.Forms.Timer autoCloseApp;
    }
}

