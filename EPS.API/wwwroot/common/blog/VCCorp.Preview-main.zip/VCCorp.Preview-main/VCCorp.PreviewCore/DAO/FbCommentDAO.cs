﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VCCorp.PreviewCore.Common;
using VCCorp.PreviewCore.DTO;

namespace VCCorp.PreviewCore.DAO
{
    public class FbCommentDAO
    {
        private readonly MySqlConnection _conn;
        public FbCommentDAO(string connection)
        {
            _conn = new MySqlConnection(connection);
        }

        public void Dispose()
        {
            Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (_conn.State == System.Data.ConnectionState.Open)
                {
                    _conn.Close();
                    _conn.Dispose();
                }
                else
                {
                    _conn.Dispose();
                }
            }
        }

        /// <summary>
        /// Select URL
        /// </summary>
        /// <param name="platform"></param>
        /// <param name="domain"></param>
        /// <returns></returns>
        public List<PostDTO> GetLinkByDomainFbCommnent(string platform,string domain)
        {
            List<PostDTO> data = new List<PostDTO>();
            string query = $"Select * from social_index_v2.fb_comment where platform ='{platform}' and is_status = {0} and link like '%{domain}%'";
            try
            {
                using (MySqlCommand cmd = new MySqlCommand(query, _conn))
                {
                    _conn.Open();
                    using (DbDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            data.Add(new PostDTO
                            {
                                id = (int)reader["id"],
                                link = reader["link"].ToString(),
                                post_id = reader["post_id"].ToString(),
                                is_status = (int)reader["is_status"],
                                platform = reader["platform"].ToString()
                            }
                            );
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }
            _conn.Close();

            return data;
        }

        public async Task<int> UpdateStatusFB_Comment(int id)
        {
            int res = 0;
            try
            {
                await _conn.OpenAsync();

                string query = $"UPDATE social_index_v2.fb_comment SET is_status = 2  WHERE id = '{id}'";

                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = _conn;
                cmd.CommandText = query;
                //cmd.Parameters.AddWithValue("@Status", content.Status);
                //cmd.Parameters.AddWithValue("@SendDate", content.SendDate);
                await cmd.ExecuteNonQueryAsync();

                res = 1;
            }
            catch (Exception ex)
            {
                if (ex.Message.ToLower().Contains("duplicate entry"))
                {
                    res = -2; // trùng link
                }
                else
                {
                    res = -1; // lỗi, bắt lỗi trả ra để sửa

                    // ghi lỗi xuống fil
                }
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }

            return res;
        }

        public async Task<int> UpdateCommentByLink(string link, int commentCount)
        {
            int res = 0;
            try
            {
                await _conn.OpenAsync();

                string query = $"Update social_index_v2.fb_comment set comment = '{commentCount}' where link = {link};";

                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = _conn;
                cmd.CommandText = query;

                await cmd.ExecuteNonQueryAsync();

                res = 1;
            }
            catch (Exception ex)
            {
                if (ex.Message.ToLower().Contains("duplicate entry"))
                {
                    res = -2; // trùng link
                }
                else
                {
                    res = -1; // lỗi, bắt lỗi trả ra để sửa
                }
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }
            return res;
        }
    }
}
