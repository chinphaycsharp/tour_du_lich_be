﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VCCorp.PreviewCore.Common;
using VCCorp.PreviewCore.DTO;

namespace VCCorp.PreviewCore.DAO
{
    public class CategoryDAO
    {
        private readonly MySqlConnection _conn;
        public CategoryDAO(string connection)
        {
            _conn = new MySqlConnection(connection);
        }

        public void Dispose()
        {
            Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (_conn.State == System.Data.ConnectionState.Open)
                {
                    _conn.Close();
                    _conn.Dispose();
                }
                else
                {
                    _conn.Dispose();
                }
            }
        }

        /// <summary>
        /// Insert URL site 
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        public List<CategoryDTO> GetSiteBySiteId(int Id)
        {
            List<CategoryDTO> result = new List<CategoryDTO>();
            string query = $"select a.*,b.Url as Domain from previewdb.categories as a left join previewdb.site as b on a.SiteId = b.Id where b.Id = {Id} and a.Status = {0};";
            try
            {
                _conn.Open();
                using (MySqlCommand cmd = new MySqlCommand(query, _conn))
                {
                    using (DbDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            CategoryDTO n = new CategoryDTO();
                            var s = reader["SendDate"].ToString();
                            n.Id = (int)reader["Id"];
                            n.Url = reader["Url"].ToString();
                            n.CreatedDateStr = Convert.ToDateTime(reader["CreatedDate"]).ToString("MM/dd/yyyy");
                            n.SendDateStr = reader["SendDate"].ToString() != "" ?  Convert.ToDateTime(reader["SendDate"]).ToString("MM/dd/yyyy") : DateTime.Now.ToString("MM/dd/yyyy");
                            n.StatusStr = (int)reader["Status"] == 1 ? "Đã bóc" : "Chưa bóc";
                            n.Domain = reader["Domain"].ToString();
                            n.Description = reader["Description"].ToString();
                            result.Add(n);
                            //result.Add
                            //(
                               
                            //    new CategoryDTO()
                            //    {
                            //        Id = (int)reader["Id"],
                            //        Url = reader["Url"].ToString(),
                            //        CreatedDateStr = Convert.ToDateTime(reader["CreatedDate"]).ToString("MM/dd/yyyy"),
                            //        SendDateStr = Convert.ToDateTime(reader["SendDate"]).ToString("MM/dd/yyyy"),
                            //        StatusStr = (int)reader["Status"] == 1 ? "Đã bóc" : "Chưa bóc",
                            //        Domain = reader["Domain"].ToString(),
                            //        Description = reader["Description"].ToString(),
                            //    }
                            //);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }
            _conn.Close();

            return result;
        }


        /// <summary>
        /// Insert URL site 
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        public CategoryDTO GetCategoryById(int Id)
        {
            CategoryDTO result = new CategoryDTO();
            string query = $"select a.*,b.Url as Domain from previewdb.categories as a left join previewdb.site as b on a.SiteId = b.Id where a.Id = {Id};";
            try
            {
                _conn.Open();
                using (MySqlCommand cmd = new MySqlCommand(query, _conn))
                {
                    using (DbDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            result.Id = (int)reader["Id"];
                            result.Url = reader["Url"].ToString();
                            result.CreatedDateStr = Convert.ToDateTime(reader["CreatedDate"]).ToString("MM/dd/yyyy");
                            result.SendDateStr = Convert.ToDateTime(reader["SendDate"]).ToString("MM/dd/yyyy");
                            result.StatusStr = (int)reader["Status"] == 1 ? "Đã bóc" : "Chưa bóc";
                            result.Domain = reader["Domain"].ToString();
                            result.Description = reader["Description"].ToString();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }
            _conn.Close();

            return result;
        }

        /// <summary>
        /// Insert URL site 
        /// </summary>
        /// <param name="Id"></param>
        /// <param name="Url"></param>
        /// <returns></returns>
        public async Task<int> UpdateCategoryById(int Id, string Url, string des)
        {
            int res = 0;
            try
            {
                await _conn.OpenAsync();

                string query = $"Update previewdb.categories set Url = '{Url}', Description = '{des}' where Id = {Id};";

                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = _conn;
                cmd.CommandText = query;

                await cmd.ExecuteNonQueryAsync();

                res = 1;
            }
            catch (Exception ex)
            {
                if (ex.Message.ToLower().Contains("duplicate entry"))
                {
                    res = -2; // trùng link
                }
                else
                {
                    res = -1; // lỗi, bắt lỗi trả ra để sửa
                }
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }

            return res;
        }

        /// <summary>
        /// Insert URL site 
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        public async Task<int> UpdateStatusAndDateCategoryById(int Id)
        {
            int res = 0;
            try
            {
                await _conn.OpenAsync();

                string query = $"Update previewdb.categories set Status= 1, SendDate = @SendDate where Id = {Id};";

                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = _conn;
                cmd.CommandText = query;
                cmd.Parameters.AddWithValue("@SendDate", DateTime.Now);

                await cmd.ExecuteNonQueryAsync();

                res = 1;
            }
            catch (Exception ex)
            {
                if (ex.Message.ToLower().Contains("duplicate entry"))
                {
                    res = -2; // trùng link
                }
                else
                {
                    res = -1; // lỗi, bắt lỗi trả ra để sửa
                }
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }

            return res;
        }

        public async Task<int> InsertCategory(CategoryDTO category)
        {
            int res = 0;

            try
            {
                await _conn.OpenAsync();

                string query = "insert ignore into previewdb.categories (Url,CreatedDate,SiteId,Description) values (@Url,@CreatedDate,@SiteId,@Description)";

                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = _conn;
                cmd.CommandText = query;

                cmd.Parameters.AddWithValue("@Url", category.Url);
                cmd.Parameters.AddWithValue("@CreatedDate", category.CreatedDate);
                cmd.Parameters.AddWithValue("@SiteId", category.SiteId);
                cmd.Parameters.AddWithValue("@Description", category.Description);

                await cmd.ExecuteNonQueryAsync();

                res = 1;
            }
            catch (Exception ex)
            {
                if (ex.Message.ToLower().Contains("duplicate entry"))
                {
                    res = -2; // trùng link
                }
                else
                {
                    res = -1; // lỗi, bắt lỗi trả ra để sửa

                    // ghi lỗi xuống fil
                }
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }

            return res;
        }


        /// <summary>
        /// Select record max order
        /// </summary>
        /// <param name="Url"></param>
        /// <returns></returns>
        public int GetCategoryByLink(string Url)
        {
            int exist = 0;
            string query = $"Select * from previewdb.categories where Url = '{Url}'";
            try
            {
                _conn.Open();
                using (MySqlCommand cmd = new MySqlCommand(query, _conn))
                {
                    using (DbDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.HasRows)
                        {
                            exist = 1;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }
            _conn.Close();

            return exist;
        }

        /// <summary>
        /// Insert URL site 
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        public async Task<int> DeleteCategoryById(int Id)
        {
            int res = 0;
            try
            {
                await _conn.OpenAsync();

                string query = $"Delete from previewdb.categories where Id = {Id};";

                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = _conn;
                cmd.CommandText = query;

                await cmd.ExecuteNonQueryAsync();

                res = 1;
            }
            catch (Exception ex)
            {
                if (ex.Message.ToLower().Contains("duplicate entry"))
                {
                    res = -2; // trùng link
                }
                else
                {
                    res = -1; // lỗi, bắt lỗi trả ra để sửa

                    // ghi lỗi xuống fil
                }
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }
            return res;
        }
    }
}
