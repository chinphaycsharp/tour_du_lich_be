﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VCCorp.PreviewCore.Common;
using VCCorp.PreviewCore.DTO;

namespace VCCorp.PreviewCore.DAO
{
    public class Si_Crawl_Data_Excel_DAO
    {
        private readonly MySqlConnection _conn;
        public Si_Crawl_Data_Excel_DAO(string connection)
        {
            _conn = new MySqlConnection(connection);
        }

        public void Dispose()
        {
            Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (_conn.State == System.Data.ConnectionState.Open)
                {
                    _conn.Close();
                    _conn.Dispose();
                }
                else
                {
                    _conn.Dispose();
                }
            }
        }

        /// <summary>
        /// Insert URL site 
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        public List<Si_Crawl_Data_ExcelDTO> GetAllSiCrawlDataExcel(string platform)
        {
            List<Si_Crawl_Data_ExcelDTO> result = new List<Si_Crawl_Data_ExcelDTO>();
            string query = $"SELECT * FROM social_index_v2.si_crawl_data_excel where platform = '{platform}';";
            try
            {
                _conn.Open();
                using (MySqlCommand cmd = new MySqlCommand(query, _conn))
                {
                    using (DbDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Si_Crawl_Data_ExcelDTO n = new Si_Crawl_Data_ExcelDTO();
                            n.id = (int)reader["Id"];
                            n.link = reader["link"].ToString();
                            n.post_id = reader["post_id"].ToString();
                            n.platform = reader["platform"].ToString();
                            n.create_time_str= reader["create_time"].ToString() != "" ? Convert.ToDateTime(reader["create_time"]).ToString("MM/dd/yyyy") : DateTime.Now.ToString("MM/dd/yyyy");
                            n.update_time_str = reader["update_time"].ToString() != "" ? Convert.ToDateTime(reader["update_time"]).ToString("MM/dd/yyyy") : DateTime.Now.ToString("MM/dd/yyyy");
                            n.status = (int)reader["status"];
                            n.comment = (int)reader["comment"];
                            n.source_id = reader["source_id"].ToString();
                            result.Add(n);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }
            _conn.Close();

            return result;
        }

        public async Task<int> UpdateCommentByLink(string link, int commentCount)
        {
            int res = 0;
            try
            {
                await _conn.OpenAsync();

                string query = $"Update social_index_v2.si_crawl_data_excel set comment = '{commentCount}' where link = {link};";

                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = _conn;
                cmd.CommandText = query;

                await cmd.ExecuteNonQueryAsync();

                res = 1;
            }
            catch (Exception ex)
            {
                if (ex.Message.ToLower().Contains("duplicate entry"))
                {
                    res = -2; // trùng link
                }
                else
                {
                    res = -1; // lỗi, bắt lỗi trả ra để sửa
                }
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }
            return res;
        }
    }
}
