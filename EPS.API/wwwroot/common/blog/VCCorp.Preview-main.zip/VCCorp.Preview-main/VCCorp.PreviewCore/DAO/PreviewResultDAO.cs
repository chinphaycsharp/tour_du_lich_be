﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VCCorp.PreviewCore.Common;
using VCCorp.PreviewCore.DTO;

namespace VCCorp.PreviewCore.DAO
{
    public class PreviewResultDAO
    {
        private readonly MySqlConnection _conn;
        public PreviewResultDAO(string connection)
        {
            _conn = new MySqlConnection(connection);
        }

        public void Dispose()
        {
            Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (_conn.State == System.Data.ConnectionState.Open)
                {
                    _conn.Close();
                    _conn.Dispose();
                }
                else
                {
                    _conn.Dispose();
                }
            }
        }

        /// <summary>
        /// Select URL
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public List<SiteDTO> GetLimitPreview(string name, List<int> status)
        {
            List<SiteDTO> data = new List<SiteDTO>();
            var s = String.Join(",", status.ToString());
            string query = $"select a.* from previewdb.site as a left join previewdb.preview_result as b on a.Id = b.SiteId where a.Status in({String.Join(",", status)}) and b.ServerName = '{name}' order by a.OrderDissection; ";
            try
            {
                using (MySqlCommand cmd = new MySqlCommand(query, _conn))
                {
                    _conn.Open();
                    using (DbDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            data.Add(new SiteDTO
                            {
                                Id = (int)reader["Id"],
                                Url = reader["Url"].ToString(),
                                CreatedDateStr = Convert.ToDateTime(reader["CreatedDate"]).ToString("MM/dd/yyyy"),
                                CrawlDateStr = Convert.ToDateTime(reader["CrawlDate"]).ToString("MM/dd/yyyy"),
                                StatusStr = (int)reader["Status"] == 1 ? "Đã bóc" : "Chưa bóc",
                                OrderDissection = (int)reader["OrderDissection"]
                            }
                            );
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }
            _conn.Close();

            return data;
        }

        /// <summary>
        /// Insert URL site 
        /// </summary>
        /// <param name="site"></param>
        /// <returns></returns>
        public async Task<int> InsertPreviewResult(PreviewResultDTO content)
        {
            int res = 0;

            try
            {
                await _conn.OpenAsync();

                string query = "insert ignore into previewdb.site (ServerName,SiteId) values (@ServerName,@SiteId)";

                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = _conn;
                cmd.CommandText = query;

                cmd.Parameters.AddWithValue("@ServerName", content.Servername);
                cmd.Parameters.AddWithValue("@SiteId", content.SiteId);

                await cmd.ExecuteNonQueryAsync();

                res = 1;
            }
            catch (Exception ex)
            {
                if (ex.Message.ToLower().Contains("duplicate entry"))
                {
                    res = -2; // trùng link
                }
                else
                {
                    res = -1; // lỗi, bắt lỗi trả ra để sửa

                    // ghi lỗi xuống fil
                }
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }

            return res;
        }
    }
}
