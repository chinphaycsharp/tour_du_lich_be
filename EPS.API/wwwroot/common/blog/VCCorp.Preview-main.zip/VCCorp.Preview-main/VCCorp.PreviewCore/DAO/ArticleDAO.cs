﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using VCCorp.PreviewCore.Common;
using VCCorp.PreviewCore.DTO;

namespace VCCorp.PreviewCore.DAO
{
    public class ArticleDAO
    {
        private readonly MySqlConnection _conn;
        public ArticleDAO(string connection)
        {
            _conn = new MySqlConnection(connection);
        }

        public void Dispose()
        {
            Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (_conn.State == System.Data.ConnectionState.Open)
                {
                    _conn.Close();
                    _conn.Dispose();
                }
                else
                {
                    _conn.Dispose();
                }
            }
        }

        /// <summary>
        /// Select URL
        /// </summary>
        /// <param name="content"></param>
        /// <returns></returns>
        /// <summary>
        /// Select URL
        public List<ContentDTO> GetLinkByDomain(string domain)
        {
            List<ContentDTO> data = new List<ContentDTO>();
            string query = $"Select * from previewdb.articles where Domain ='{domain}' and Status ={0}";
            try
            {
                using (MySqlCommand cmd = new MySqlCommand(query, _conn))
                {
                    _conn.Open();
                    using (DbDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            data.Add(new ContentDTO
                            {
                                ReferUrl = reader["Url"].ToString(),
                                Status = (int)reader["Status"]
                            }
                            );
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }
            _conn.Close();

            return data;
        }

        /// <summary>
        /// Insert URL site 
        /// </summary>
        /// <param name="status"></param>
        /// <returns></returns>
        public List<ArticleDTO> GetArticles(int status, bool all, int siteId)
        {
            List<ArticleDTO> data = new List<ArticleDTO>();
            string query = $"select a.* from previewdb.articles a left join previewdb.categories b on a.CategoryId = b.Id where b.SiteId={siteId}";
            string subQuery = "";
            if (all == false)
            {
                subQuery = $"and Status ={status}";
            }
            query = query + subQuery + ";";
            try
            {
                _conn.Open();
                using (MySqlCommand cmd = new MySqlCommand(query, _conn))
                {
                    using (DbDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            data.Add(new ArticleDTO
                            {
                                Id = (int)reader["Id"],
                                Url = reader["Url"].ToString(),
                                CreatedDateStr = Convert.ToDateTime(reader["CreatedDate"]).ToString("MM/dd/yyyy"),
                                SendDateStr = Convert.ToDateTime(reader["SendDate"]).ToString("MM/dd/yyyy"),
                                StatusStr = (int)reader["Status"] == 1 ? "Đã bóc" : "Chưa bóc",
                                Title = reader["Title"].ToString()
                            }
                             );
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }
            _conn.Close();

            return data;
        }

        /// <summary>
        /// Select URL
        /// </summary>
        /// <param name="content"></param>
        /// <returns></returns>
        /// <summary>
        /// Select URL
        public List<ContentDTO> GetLinkByCategoryId(int categoryId)
        {
            List<ContentDTO> data = new List<ContentDTO>();
            string query = $"Select * from previewdb.articles where CategoryId ='{categoryId}' and Status ={0}";
            try
            {
                using (MySqlCommand cmd = new MySqlCommand(query, _conn))
                {
                    _conn.Open();
                    using (DbDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            data.Add(new ContentDTO
                            {
                                ReferUrl = reader["Url"].ToString(),
                                Status = (int)reader["Status"]
                            }
                            );
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }
            _conn.Close();

            return data;
        }

        /// <summary>
        /// Update status
        /// </summary>
        /// <param name="content"></param>
        /// <returns></returns>
        public async Task<int> UpdateStatus(string url, string content)
        {
            //ContentDTO content = new ContentDTO();
            int res = 0;
            try
            {
                await _conn.OpenAsync();

                string query = $"UPDATE previewdb.articles SET Status = 1, SendDate = @SendDate, Content = @Content WHERE Url = '{url}'";

                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = _conn;
                cmd.CommandText = query;
                cmd.Parameters.AddWithValue("@SendDate", DateTime.Now);
                cmd.Parameters.AddWithValue("@Content", content);
                await cmd.ExecuteNonQueryAsync();

                res = 1;
            }
            catch (Exception ex)
            {
                if (ex.Message.ToLower().Contains("duplicate entry"))
                {
                    res = -2; // trùng link
                }
                else
                {
                    res = -1; // lỗi, bắt lỗi trả ra để sửa

                    // ghi lỗi xuống fil
                }
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }

            return res;
        }

        /// <summary>
        /// Select URL
        /// </summary>
        /// <param name="day"></param>
        /// <returns></returns>
        public List<ArticleDTO> StastisticArticles(int day)
        {
            List<ArticleDTO> data = new List<ArticleDTO>();
            string query = $"SELECT a.*,b.Url as  CategoryName FROM previewdb.articles as a left join previewdb.categories as b on a.CategoryId = b.Id";
            string subQuery = "";
            if(day >= 0)
            {
                subQuery = $" WHERE DATE(a.CreatedDate) >= DATE(NOW() - INTERVAL {day} DAY) order by a.CreatedDate desc;";
            }
            else
            {
                subQuery = $" order by a.CreatedDate desc;";
            }
            query = query + subQuery;
            try
            {
                using (MySqlCommand cmd = new MySqlCommand(query, _conn))
                {
                    _conn.Open();
                    using (DbDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            data.Add(new ArticleDTO
                            {
                                Id = (int)reader["Id"],
                                Url = reader["Url"].ToString(),
                                CreatedDateStr = Convert.ToDateTime(reader["CreatedDate"]).ToString("MM/dd/yyyy"),
                                SendDateStr = Convert.ToDateTime(reader["SendDate"]).ToString("MM/dd/yyyy"),
                                StatusStr = (int)reader["Status"] == 1 ? "Đã bóc" : "Chưa bóc",
                                Content = reader["Content"].ToString(),
                                Title = reader["Title"].ToString(),
                                CategoryId = (int)reader["CategoryId"],
                                DomainName = Regex.Match(reader["CategoryName"].ToString(), @".+(?<=.vn|.com)", RegexOptions.Singleline).Value
                            }
                            );
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }
            _conn.Close();

            return data;
        }

        /// <summary>
        /// Insert URL content 
        /// </summary>
        /// <param name="article"></param>
        /// <returns></returns>
        public async Task<int> InsertArticle(ArticleDTO article,int categoryId)
        {
            int res = 0;

            try
            {
                if(_conn.State == ConnectionState.Closed)
                {
                    await _conn.OpenAsync();
                }

                string query = "insert ignore into previewdb.articles (Url,Content,Title,CategoryId) values (@Url,@Content,@Title,@CategoryId)";

                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = _conn;
                cmd.CommandText = query;

                cmd.Parameters.AddWithValue("@Url", article.Url);
                cmd.Parameters.AddWithValue("@Content", article.Content);
                cmd.Parameters.AddWithValue("@Title", article.Title);
                cmd.Parameters.AddWithValue("@CategoryId", categoryId);

                await cmd.ExecuteNonQueryAsync();

                res = 1;

            }
            catch (Exception ex)
            {
                if (ex.Message.ToLower().Contains("duplicate entry"))
                {
                    res = -2; // trùng link
                }
                else
                {
                    res = -1; // lỗi, bắt lỗi trả ra để sửa

                    // ghi lỗi xuống fil
                }
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }

            return res;
        }
    }
}
