﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VCCorp.PreviewCore.Common;
using VCCorp.PreviewCore.DTO;

namespace VCCorp.PreviewCore.DAO
{
    public class SiteDAO
    {
        private readonly MySqlConnection _conn;
        public SiteDAO(string connection)
        {
            _conn = new MySqlConnection(connection);
        }

        public void Dispose()
        {
            Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (_conn.State == System.Data.ConnectionState.Open)
                {
                    _conn.Close();
                    _conn.Dispose();
                }
                else
                {
                    _conn.Dispose();
                }
            }
        }

        /// <summary>
        /// Insert URL site 
        /// </summary>
        /// <param name="site"></param>
        /// <returns></returns>
        public async Task<int> InsertSite(SiteDTO content)
        {
            int res = 0;

            try
            {
                await _conn.OpenAsync();

                string query = "insert ignore into previewdb.site (Url,CreatedDate,OrderDissection) values (@Url,@CreatedDate,@OrderDissection)";

                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = _conn;
                cmd.CommandText = query;

                cmd.Parameters.AddWithValue("@Url", content.Url);
                cmd.Parameters.AddWithValue("@CreatedDate", content.CreatedDate);
                cmd.Parameters.AddWithValue("@OrderDissection", content.OrderDissection);

                await cmd.ExecuteNonQueryAsync();

                res = 1;
            }
            catch (Exception ex)
            {
                if (ex.Message.ToLower().Contains("duplicate entry"))
                {
                    res = -2; // trùng link
                }
                else
                {
                    res = -1; // lỗi, bắt lỗi trả ra để sửa

                    // ghi lỗi xuống fil
                }
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }

            return res;
        }

        /// <summary>
        /// Select URL
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public List<SiteDTO> GetSitesLimit(List<int> status)
        {
            List<SiteDTO> data = new List<SiteDTO>();
            string query = $"select a.* from previewdb.site as a left join previewdb.preview_result as b on a.Id = b.SiteId where b.ServerName is null and Status in ({String.Join(",", status)}) order by a.OrderDissection limit 15;";
            try
            {
                using (MySqlCommand cmd = new MySqlCommand(query, _conn))
                {
                    _conn.Open();
                    using (DbDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            data.Add(new SiteDTO
                            {
                                Id = (int)reader["Id"],
                                Url = reader["Url"].ToString(),
                                CreatedDateStr = Convert.ToDateTime(reader["CreatedDate"]).ToString("MM/dd/yyyy"),
                                CrawlDateStr = Convert.ToDateTime(reader["CrawlDate"]).ToString("MM/dd/yyyy"),
                                StatusStr = (int)reader["Status"] == 1 ? "Đã bóc" : "Chưa bóc",
                                OrderDissection = (int)reader["OrderDissection"]
                            }
                            );
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }
            _conn.Close();

            return data;
        }

        /// <summary>
        /// Select URL
        /// </summary>
        /// <returns></returns>
        public List<SiteDTO> GetAllSites()
        {
            List<SiteDTO> data = new List<SiteDTO>();
            string query = $"Select * from previewdb.site where Status = {0}";
            try
            {
                using (MySqlCommand cmd = new MySqlCommand(query, _conn))
                {
                    _conn.Open();
                    using (DbDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            data.Add(new SiteDTO
                            {
                                Id = (int)reader["Id"],
                                Url = reader["Url"].ToString(),
                                CreatedDateStr = Convert.ToDateTime(reader["CreatedDate"]).ToString("MM/dd/yyyy"),
                                CrawlDateStr = Convert.ToDateTime(reader["CrawlDate"]).ToString("MM/dd/yyyy"),
                                StatusStr = (int)reader["Status"] == 1 ? "Đã bóc" : "Chưa bóc",
                                OrderDissection = (int)reader["OrderDissection"],
                                BotNameDessection = reader["BotNameDessection"].ToString()
                            }
                            );
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }
            _conn.Close();

            return data;
        }

        /// <summary>
        /// Select record max order
        /// </summary>
        /// <param name="Url"></param>
        /// <returns></returns>
        public int GetSiteByLink(string Url)
        {
            int exist = 0;
            string query = $"Select * from previewdb.site where Url = '{Url}'";
            try
            {
                _conn.Open();
                using (MySqlCommand cmd = new MySqlCommand(query, _conn))
                {
                    using (DbDataReader reader = cmd.ExecuteReader())
                    {
                        if(reader.HasRows)
                        {
                            exist = 1;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }
            _conn.Close();

            return exist;
        }

        /// <summary>
        /// Insert URL site 
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        public SiteDTO GetSiteById(int Id)
        {
            SiteDTO result = new SiteDTO();
            string query = $"Select * from previewdb.site where Id = {Id} and Status = {0}";
            try
            {
                _conn.Open();
                using (MySqlCommand cmd = new MySqlCommand(query, _conn))
                {
                    using (DbDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            result.Id = (int)reader["Id"];
                            result.Url = reader["Url"].ToString();
                            result.CreatedDateStr = Convert.ToDateTime(reader["CreatedDate"]).ToString("MM/dd/yyyy");
                            result.CrawlDateStr = Convert.ToDateTime(reader["CrawlDate"]).ToString("MM/dd/yyyy");
                            result.StatusStr = (int)reader["Status"] == 1 ? "Đã bóc" : "Chưa bóc";
                            result.OrderDissection = (int)reader["OrderDissection"];
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }
            _conn.Close();

            return result;
        }

        /// <summary>
        /// Insert URL site 
        /// </summary>
        /// <param name="Id"></param>
        /// /// <param name="Url"></param>
        /// <returns></returns>
        public async Task<int> UpdateSiteById(int Id, string Url, int OrderDissection)
        {
            int res = 0;
            try
            {
                await _conn.OpenAsync();

                string query = $"Update previewdb.site set Url = '{Url}', OrderDissection = {OrderDissection} where Id = {Id}";

                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = _conn;
                cmd.CommandText = query;

                await cmd.ExecuteNonQueryAsync();

                res = 1;
            }
            catch (Exception ex)
            {
                if (ex.Message.ToLower().Contains("duplicate entry"))
                {
                    res = -2; // trùng link
                }
                else
                {
                    res = -1; // lỗi, bắt lỗi trả ra để sửa

                    // ghi lỗi xuống fil
                }
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }

            return res;
        }

        /// <summary>
        /// Insert URL site 
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        public async Task<int> UpdateStatusAndDateSiteById(int Id)
        {
            int res = 0;
            try
            {
                await _conn.OpenAsync();

                string query = $"Update previewdb.site set Status = 1, SendDate = @SendDate where Id = {Id}";

                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = _conn;
                cmd.CommandText = query;
                cmd.Parameters.AddWithValue("@SendDate", DateTime.Now);
                await cmd.ExecuteNonQueryAsync();

                res = 1;
            }
            catch (Exception ex)
            {
                if (ex.Message.ToLower().Contains("duplicate entry"))
                {
                    res = -2; // trùng link
                }
                else
                {
                    res = -1; // lỗi, bắt lỗi trả ra để sửa

                    // ghi lỗi xuống fil
                }
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }

            return res;
        }

        /// <summary>
        /// Insert URL site 
        /// </summary>
        /// <param name="Id"></param>
        /// /// <param name="Url"></param>
        /// <returns></returns>
        public async Task<int> UpdateSiteStatusAndCrawlDate(int id)
        {
            int res = 0;
            try
            {
                await _conn.OpenAsync();

                string query = $"Update previewdb.site set Status = 1, CrawlDate = @SendDate where Id = {id}";

                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = _conn;
                cmd.CommandText = query;
                cmd.Parameters.AddWithValue("@SendDate", DateTime.Now);
                await cmd.ExecuteNonQueryAsync();

                res = 1;
            }
            catch (Exception ex)
            {
                if (ex.Message.ToLower().Contains("duplicate entry"))
                {
                    res = -2; // trùng link
                }
                else
                {
                    res = -1; // lỗi, bắt lỗi trả ra để sửa

                    // ghi lỗi xuống fil
                }
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }

            return res;
        }

        /// <summary>
        /// Insert URL site 
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        public async Task<int> UpdateSiteIsDessection(int Id)
        {
            int res = 0;
            try
            {
                await _conn.OpenAsync();

                string query = $"Update previewdb.site set IsDessection = {1} where Id = {Id}";

                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = _conn;
                cmd.CommandText = query;

                await cmd.ExecuteNonQueryAsync();

                res = 1;
            }
            catch (Exception ex)
            {
                if (ex.Message.ToLower().Contains("duplicate entry"))
                {
                    res = -2; // trùng link
                }
                else
                {
                    res = -1; // lỗi, bắt lỗi trả ra để sửa

                    // ghi lỗi xuống fil
                }
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }

            return res;
        }

        /// <summary>
        /// Insert URL site 
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        public async Task<int> DeleteSiteById(int Id)
        {
            int res = 0;
            try
            {
                await _conn.OpenAsync();

                string query = $"Delete from previewdb.site where Id = {Id};";

                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = _conn;
                cmd.CommandText = query;

                await cmd.ExecuteNonQueryAsync();

                res = 1;
            }
            catch (Exception ex)
            {
                if (ex.Message.ToLower().Contains("duplicate entry"))
                {
                    res = -2; // trùng link
                }
                else
                {
                    res = -1; // lỗi, bắt lỗi trả ra để sửa

                    // ghi lỗi xuống fil
                }
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }

            return res;
        }
    }
}
