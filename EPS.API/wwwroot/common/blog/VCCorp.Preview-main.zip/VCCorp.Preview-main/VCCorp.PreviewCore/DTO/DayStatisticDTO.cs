﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VCCorp.PreviewCore.DTO
{
    public class DayStatisticDTO
    {
        public int Value { get; set; }
        public string Text { get; set; }

        public static List<DayStatisticDTO> days = new List<DayStatisticDTO>()
        {
            new DayStatisticDTO()
            {
                Value = -1,
                Text = "Tất cả"
            },
            new DayStatisticDTO()
            {
                Value = 0,
                Text = "Hôm nay"
            },
            new DayStatisticDTO()
            {
                Value = 1,
                Text = "Hôm qua"
            },
            new DayStatisticDTO()
            {
                Value = 2,
                Text = "Hôm kia"
            },
            new DayStatisticDTO()
            {
                Value = 7,
                Text = "Trong vòng 7 ngày"
            },
        };
    }
}
