﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VCCorp.PreviewCore.DTO
{
    public class SiteDTO
    {
        public int Id { get; set; }
        public string Url { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime CrawlDate { get; set; }
        public string CreatedDateStr { get; set; }
        public string CrawlDateStr { get; set; }
        public int Status { get; set; }
        public string StatusStr { get; set; }
        public int OrderDissection { get; set; }
        public string BotNameDessection { get; set; }
    }
}
