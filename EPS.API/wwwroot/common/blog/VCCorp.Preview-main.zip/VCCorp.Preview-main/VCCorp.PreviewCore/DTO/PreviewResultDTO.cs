﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VCCorp.PreviewCore.DTO
{
    public class PreviewResultDTO
    {
        public int Id { get; set; }
        public string Servername { get; set; }
        public string CreatedDateStr { get; set; }
        public int SiteId { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}
