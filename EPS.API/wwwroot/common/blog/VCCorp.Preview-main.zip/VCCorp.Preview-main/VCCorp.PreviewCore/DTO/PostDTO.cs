﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VCCorp.PreviewCore.DTO
{
    public class PostDTO
    {
        public int id { get; set; }
        public string post_id { get; set; }
        public int user_id { get; set; }
        public DateTime start_time { get; set; }
        public DateTime end_time { get; set; }
        public int is_status { get; set; }
        public int is_deleted { get; set; }
        public DateTime update_time { get; set; }
        public DateTime create_time { get; set; }
        public int code { get; set; }
        public int is_get_comment { get; set; }
        public int type { get; set; }
        public string platform { get; set; }
        public string link { get; set; }
        public int topic_id { get; set; }
        public string topic_name { get; set; }
        public string description_err { get; set; }
        public int request_id { get; set; }
    }
}
