﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VCCorp.PreviewCore.DTO
{
    public class CommentDTO_BigData
    {
        public string post_Id { get; set; }
        public string Create_Time_String { get; set; }
        public DateTime Create_time { get; set; }
        public DateTime Get_Time { get; set; }
        public string Get_Time_String { get; set; }
        public string Comment { get; set; }
        public string Author { get; set; }
        public string Url { get; set; }
    }
}
