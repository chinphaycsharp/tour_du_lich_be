﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VCCorp.PreviewCore.DTO
{
    public class Si_Crawl_Data_ExcelDTO
    {
        public int id { get; set; }
        public string post_id { get; set; }
        public string platform { get; set; }
        public string link { get; set; }
        public DateTime create_time { get; set; }
        public string create_time_str { get; set; }
        public DateTime update_time { get; set; }
        public string update_time_str { get; set; }
        public int status { get; set; }
        public int comment { get; set; }
        public string source_id { get; set; }
    }
}
