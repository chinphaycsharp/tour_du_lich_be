﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VCCorp.PreviewCore.Data
{
    public class DataVnTrip
    {
        public class Datum
        {
            public int vntrip_id { get; set; }
            public string provider { get; set; }
            public string checkin_date { get; set; }
            public int nights { get; set; }
            public bool has_business_rate { get; set; }
            public double price { get; set; }
            public double min_price { get; set; }
            public double net_price { get; set; }
            public int rooms_available { get; set; }
            public DateTime last_update { get; set; }
            public int id { get; set; }
            public string name { get; set; }
            public string name_vi { get; set; }
            public string full_address { get; set; }
            public int province_id { get; set; }
            public int city_id { get; set; }
            public string star_rate { get; set; }
            public string type { get; set; }
            public bool discount_active { get; set; }
            public Location location { get; set; }
            public bool free_shuttle { get; set; }
            public string full_address_en { get; set; }
            public List<object> groupFacilities { get; set; }
            public double ranking_score { get; set; }
            public double review_point { get; set; }
            public int count_reviews { get; set; }
            public string thumb_image { get; set; }
            public int price_one_night { get; set; }
            public ShowPrices show_prices { get; set; }
            public List<string> mapping_providers { get; set; }
            public List<object> tags { get; set; }
            public bool have_360img { get; set; }
            public bool is_special { get; set; }
            public string tms_special_hotel_policy { get; set; }
            public bool is_tms_special_hotel { get; set; }
            public bool is_over_policy { get; set; }
        }

        public class DiscountCoupon
        {
            public string title { get; set; }
            public string discount_type { get; set; }
            public string discount_value { get; set; }
            public int incl_vat_fee_price { get; set; }
            public int excl_vat_fee_price { get; set; }
            public int order { get; set; }
            public bool show { get; set; }
        }

        public class FinalPrice
        {
            public string title { get; set; }
            public string discount_type { get; set; }
            public int incl_discount_value { get; set; }
            public int excl_discount_value { get; set; }
            public int incl_vat_fee_price { get; set; }
            public int excl_vat_fee_price { get; set; }
            public int order { get; set; }
            public bool show { get; set; }
        }

        public class Location
        {
            public double lat { get; set; }
            public double lon { get; set; }
        }

        public class LoyaltyDiscount
        {
            public string title { get; set; }
            public string discount_type { get; set; }
            public string discount_value { get; set; }
            public int incl_vat_fee_price { get; set; }
            public int excl_vat_fee_price { get; set; }
            public int order { get; set; }
            public bool show { get; set; }
        }

        public class MemberDiscount
        {
            public string title { get; set; }
            public string discount_type { get; set; }
            public string discount_value { get; set; }
            public int incl_vat_fee_price { get; set; }
            public int excl_vat_fee_price { get; set; }
            public int order { get; set; }
            public bool show { get; set; }
        }

        public class MobileRate
        {
            public string title { get; set; }
            public string discount_type { get; set; }
            public string discount_value { get; set; }
            public int incl_vat_fee_price { get; set; }
            public int excl_vat_fee_price { get; set; }
            public int order { get; set; }
            public bool show { get; set; }
        }

        public class Promotion
        {
            public string title { get; set; }
            public string discount_type { get; set; }
            public string discount_value { get; set; }
            public int incl_vat_fee_price { get; set; }
            public int excl_vat_fee_price { get; set; }
            public int order { get; set; }
            public string end_time { get; set; }
            public bool show { get; set; }
        }

        public class Root
        {
            public List<Datum> data { get; set; }
        }

        public class ShowPrices
        {
            public Promotion promotion { get; set; }
            public MemberDiscount member_discount { get; set; }
            public MobileRate mobile_rate { get; set; }
            public LoyaltyDiscount loyalty_discount { get; set; }
            public DiscountCoupon discount_coupon { get; set; }
            public FinalPrice final_price { get; set; }
        }
    }
}
