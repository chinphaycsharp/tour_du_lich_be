﻿using CefSharp.WinForms;
using HtmlAgilityPack;
using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using VCCorp.PreviewCore.Common;
using VCCorp.PreviewCore.DAO;
using VCCorp.PreviewCore.DTO;
using VCCorp.PreviewCore.Kafka;

namespace VCCorp.PreviewCore.BUS
{
    public class ParserFoody
    {
        private ChromiumWebBrowser _browser = null;
        private readonly HtmlAgilityPack.HtmlDocument _document = new HtmlAgilityPack.HtmlDocument();
        private const string _jsClickShowMoreRestaurant = @"document.getElementsByClassName('fd-btn-more')[0].click()";
        private const string _jsScroll = @"window.scrollTo(0, document.body.scrollHeight/1)";
        private const string _jsAutoScroll1 = @"function pageScroll() {window.scrollBy(0,10);scrolldelay = setTimeout(pageScroll,30);}{window.scrollBy(0,10);scrolldelay = setTimeout(pageScroll,30);}";
        private string URL_FOODY = "https://www.foody.vn/";

        public ParserFoody()
        {
        }
        public ParserFoody(ChromiumWebBrowser browser)
        {
            _browser = browser;
        }

        public async Task<string> CrawlDataPost(string Url, int id)
        {
            string message = "";
            try
            {
                await GetListPost(Url, id);
                CategoryDAO categoryDAO = new CategoryDAO(ConnectionDAO.ConnectionToTableLinkProduct);
                await categoryDAO.UpdateStatusAndDateCategoryById(id);
                categoryDAO.Dispose();
            }
            catch (Exception ex)
            {
                message = ex.Message;
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }
            return message;
        }

        public async Task<string> CrawlDetailPost(int id)
        {
            string message = "";
            try
            {
                await GetPostDetail(id);
            }
            catch (Exception ex)
            {
                message = ex.Message;
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }
            return message;
        }

        public async Task<List<ArticleDTO>> GetListPost(string url, int categoryId)
        {
            List<ArticleDTO> contentList = new List<ArticleDTO>();
            try
            {
                await _browser.LoadUrlAsync(url);
                await Task.Delay(TimeSpan.FromMinutes(1));
                ushort indexLastContent = 0;
                ushort scroll = 0;

                while (true)
                {
                    //indexLastContent = 0;
                    if(indexLastContent >= 200)
                    {
                        break;
                    }
                    scroll = 0;
                    while (scroll <= 10)
                    {
                        await Common.Utilities.EvaluateJavaScriptSync(_jsScroll, _browser).ConfigureAwait(false);
                        string checkJs1 = await Common.Utilities.EvaluateJavaScriptSync(_jsClickShowMoreRestaurant, _browser).ConfigureAwait(false);
                        if (checkJs1 == null)
                        {
                            break;
                        }
                        await Task.Delay(TimeSpan.FromSeconds(5));
                        scroll++;
                    }
                    string html = await Common.Utilities.GetBrowserSource(_browser).ConfigureAwait(false);                                                                                       
                    _document.LoadHtml(html);
                    html = null;

                    HtmlNodeCollection divComment = _document.DocumentNode.SelectNodes($"//div[contains(@class,'content-item ng-scope')][position()>{indexLastContent}]");
                    if (divComment == null)
                    {
                        continue;
                    }
                    else
                    {
                        foreach (HtmlNode item in divComment)
                        {
                            string listURL = item.SelectSingleNode(".//a[contains(@class,'ng-binding')]")?.Attributes["href"]?.Value ?? "";
                            //loại bỏ kí tự đằng sau dấu '?' chỉ lấy id hotel
                            listURL = Regex.Replace(listURL, @"\?[\s\S]+", " ", RegexOptions.IgnoreCase);
                            ArticleDTO content = new ArticleDTO();
                            content.Url = listURL;
                            content.CreatedDate = DateTime.Now; // ngày bóc tách
                            content.CreateDate_Timestamp = Common.Utilities.DateTimeToUnixTimestamp(DateTime.Now); // ngày bóc tách chuyển sang dạng Timestamp
                            content.DomainName = URL_FOODY;
                            content.Title = item.SelectSingleNode(".//div[contains(@class,'desc fd-text-ellip ng-binding')]")?.InnerText ?? "";
                            content.Status = 0;
                            contentList.Add(content);

                            ArticleDAO msql = new ArticleDAO(ConnectionDAO.ConnectionToTableLinkProduct);
                            await msql.InsertArticle(content, categoryId);
                            msql.Dispose();

                            indexLastContent++;
                        }
                    }
                    
                    await Task.Delay(TimeSpan.FromSeconds(10));
                }
            }
            catch(Exception ex) {
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }
            return contentList;
        }

        /// <summary>
        /// Lấy nội dung bình luận
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        public async Task<List<DTO.CommentDTO>> GetPostDetail(int categoryId)
        {
            List<DTO.CommentDTO> commentList = new List<DTO.CommentDTO>();
            ushort indexLastComment = 0;
            try
            {
                ArticleDAO contentDAO = new ArticleDAO(ConnectionDAO.ConnectionToTableLinkProduct);
                List<ContentDTO> dataUrl = contentDAO.GetLinkByCategoryId(categoryId);
                //byte indexLoadComment = 0;
                contentDAO.Dispose();
                for (int i = 0; i < dataUrl.Count; i++)
                {
                    indexLastComment = 0;
                    //indexLoadComment = 0;
                    int status = dataUrl[i].Status;
                    if (status == 0)// check xem đã bóc hay chưa?
                    {
                        if (dataUrl[i].ReferUrl == "")
                        {
                            continue;
                        }
                        string url = URL_FOODY + dataUrl[i].ReferUrl;
                        await _browser.LoadUrlAsync(url);
                        await Task.Delay(TimeSpan.FromSeconds(10));
                        string checkJs1 = await Common.Utilities.EvaluateJavaScriptSync(_jsAutoScroll1, _browser).ConfigureAwait(false);
                        await Task.Delay(TimeSpan.FromSeconds(10));
                        string html = await Common.Utilities.GetBrowserSource(_browser).ConfigureAwait(false);
                        _document.LoadHtml(html);
                        html = null;

                        //Lấy hotel details
                        ContentDTO content = new ContentDTO();
                        content.Subject = _document.DocumentNode.SelectSingleNode("//div[contains(@class,'main-info-title')]//h1")?.InnerText;
                        content.Contents = "";
                        content.ImageThumb = _document.DocumentNode.SelectSingleNode("//img[contains(@class,'pic-place')]")?.Attributes["src"]?.Value ?? "";
                        content.Domain = URL_FOODY;
                        content.ReferUrl = url;
                        content.CreateDate = DateTime.Now;
                        content.Category = _document.DocumentNode.SelectSingleNode("//div[contains(@class,'category')]//div[contains(@class,'category-items')]//a")?.InnerText;
                        //Lưu vào Db
                        //ContentDAO msql = new ContentDAO(ConnectionDAO.ConnectionToTableLinkProduct);
                        //await msql.InserContent(content);
                        //msql.Dispose();

                        //Update Status (crawled == 1 )
                        ArticleDAO msql1 = new ArticleDAO(ConnectionDAO.ConnectionToTableLinkProduct);
                        await msql1.UpdateStatus(dataUrl[i].ReferUrl, content.Contents);
                        msql1.Dispose();

                        #region gửi đi cho ILS

                        ArticleDTO_BigData ent = new ArticleDTO_BigData();

                        ent.Id = Common.Utilities.Md5Encode(url);
                        ent.Content = content.Contents;

                        //Get_Time là thời gian bóc 
                        ent.Get_Time = content.CreateDate;
                        ent.Get_Time_String = content.CreateDate.ToString("yyyy-MM-dd HH:mm:ss");

                        ent.Description = content.Summary;

                        ent.Title = content.Subject;
                        ent.Url = content.ReferUrl;
                        ent.Source_Id = "0";
                        ent.Category = content.Category;
                        ent.Image = content.ImageThumb;
                        ent.urlAmphtml = "";
                        ent.ContentNoRemoveHtml = ""; // xóa đi khi lưu xuống cho nhẹ

                        string jsonPost = KafkaPreview.ToJson<ArticleDTO_BigData>(ent);
                        KafkaPreview kafka = new KafkaPreview();
                        await kafka.InsertPost(jsonPost, "crawler-preview-post");
                        #endregion

                        //while (indexLoadComment < 20)
                        //{
                        //    indexLoadComment++;
                        //    string checkJs1 = await Common.Utilities.EvaluateJavaScriptSync(_jsAutoScroll1, _browser).ConfigureAwait(false);
                        //    if (checkJs1 == null)
                        //    {
                        //        break;
                        //    }
                        //    //await Task.Delay(5_000);
                        //    await Task.Delay(1_500);
                        //}
                        int countCmt = 0;
                        string html1 = await Common.Utilities.GetBrowserSource(_browser).ConfigureAwait(false);
                        _document.LoadHtml(html1);
                        html1 = null;
                        while (true)
                        {
                            //Lấy list comment
                            HtmlNodeCollection divComment = _document.DocumentNode.SelectNodes($"//li[contains(@class,'review-item fd-clearbox ng-scope')][position()>{indexLastComment}]");
                            HtmlNode contentComment = _document.DocumentNode.SelectSingleNode($"//div[contains(@class,'rd-des')]/span[contains(@class,'ng-binding')]");
                            if (divComment == null)
                            {
                                break;
                            }
                            else
                            {
                                foreach (HtmlNode item in divComment)
                                {
                                    DTO.CommentDTO commentDTO = new DTO.CommentDTO();
                                    commentDTO.Point = item.SelectSingleNode(".//div[contains(@class,'review-points ng-scope green')]/span[contains(@class,'ng-binding')]")?.InnerText;
                                    string author = item.SelectSingleNode(".//div[contains(@class,'ru-row')]/a[contains(@class,'ru-username ng-binding')]")?.InnerText;
                                    commentDTO.Author = author;
                                    commentDTO.ContentsComment = Common.Utilities.RemoveSpecialCharacter(item.SelectSingleNode(".//div[contains(@class,'rd-des')]/span[contains(@class,'ng-binding')]")?.InnerText);
                                    HtmlNodeCollection divReply = item.SelectNodes($".//li[contains(@class,'ng-scope')]/div[contains(@class,'fc-right')]");

                                    //Xử lý reply trong các comment lớn
                                    if (divReply != null)
                                    {
                                        foreach (var itemReply in divReply)
                                        {
                                            DTO.CommentDTO replyDTO = new DTO.CommentDTO();
                                            replyDTO.Point = "Reply";
                                            string authorReply = itemReply.SelectSingleNode(".//a[contains(@class,'fc-username ng-binding')]")?.InnerText;
                                            replyDTO.Author = authorReply;
                                            replyDTO.ContentsComment = Common.Utilities.RemoveSpecialCharacter(itemReply.SelectSingleNode(".//span[contains(@class,'fc-user-comment ng-binding')]")?.InnerText);
                                            DateTime postDateReply = DateTime.Now;
                                            string datecommentReply = item.SelectSingleNode(".//li/div[contains(@class,'ng-binding')]")?.InnerText;
                                            if (!string.IsNullOrEmpty(datecommentReply))
                                            {
                                                Common.DateTimeFormatAgain dtFomat = new Common.DateTimeFormatAgain();
                                                string date = dtFomat.GetDateByPattern(datecommentReply, "dd/MM/yyyy");

                                                try
                                                {
                                                    postDateReply = Convert.ToDateTime(date);
                                                }
                                                catch(Exception ex) {
                                                    var type = this.GetType().Name;
                                                    Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
                                                }
                                            }
                                            replyDTO.PostDate = postDateReply;
                                            replyDTO.CreateDate = DateTime.Now;
                                            replyDTO.Domain = URL_FOODY;
                                            replyDTO.ReferUrl = url;
                                            CommentDTO_BigData entiReply = new CommentDTO_BigData();
                                            entiReply.post_Id = Common.Utilities.Md5Encode(url);
                                            entiReply.Comment = replyDTO.ContentsComment;
                                            entiReply.Author = replyDTO.Author;
                                            entiReply.Url = replyDTO.ReferUrl;
                                            // thời gian tạo tin
                                            entiReply.Create_time = replyDTO.PostDate;
                                            entiReply.Create_Time_String = replyDTO.PostDate.ToString("yyyy-MM-dd HH:mm:ss");

                                            //Get_Time là thời gian bóc 
                                            entiReply.Get_Time = replyDTO.CreateDate;
                                            entiReply.Get_Time_String = replyDTO.CreateDate.ToString("yyyy-MM-dd HH:mm:ss");
                                            string jsonPostReply = KafkaPreview.ToJson<CommentDTO_BigData>(entiReply);
                                            KafkaPreview kafkaReply = new KafkaPreview();
                                            await kafkaReply.InsertPost(jsonPostReply, "crawler-preview-post-comment");
                                        }
                                    }

                                    DateTime postDate = DateTime.Now;
                                    string datecomment = item.SelectSingleNode(".//section/div[contains(@class,'uitk-type-300 uitk-text-default-theme')]/span")?.InnerText;
                                    if (!string.IsNullOrEmpty(datecomment))
                                    {
                                        Common.DateTimeFormatAgain dtFomat = new Common.DateTimeFormatAgain();
                                        string date = dtFomat.GetDateByPattern(datecomment, "dd/MM/yyyy");

                                        try
                                        {
                                            postDate = Convert.ToDateTime(date);
                                        }
                                        catch(Exception ex) {
                                            var type = this.GetType().Name;
                                            Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
                                        }
                                    }
                                    commentDTO.PostDate = postDate;
                                    commentDTO.CreateDate = DateTime.Now;
                                    commentDTO.Domain = URL_FOODY;
                                    commentDTO.ReferUrl = url;
                                    commentList.Add(commentDTO);
                                    countCmt++;
                                    //Lưu về db
                                    //CommentDAO msql2 = new CommentDAO(ConnectionDAO.ConnectionToTableLinkProduct);
                                    //await msql2.InsertListComment(commentDTO);
                                    //msql2.Dispose();

                                    #region gửi đi cho ILS

                                    CommentDTO_BigData enti = new CommentDTO_BigData();
                                    enti.post_Id = ent.Id;
                                    enti.Comment = commentDTO.ContentsComment;
                                    enti.Author = commentDTO.Author;
                                    enti.Url = commentDTO.ReferUrl;
                                    // thời gian tạo tin
                                    enti.Create_time = commentDTO.PostDate;
                                    enti.Create_Time_String = commentDTO.PostDate.ToString("yyyy-MM-dd HH:mm:ss");

                                    //Get_Time là thời gian bóc 
                                    enti.Get_Time = commentDTO.CreateDate;
                                    enti.Get_Time_String = commentDTO.CreateDate.ToString("yyyy-MM-dd HH:mm:ss");
                                    //enti.Url = commentDTO.ReferUrl;

                                    ////Get_Time là thời gian bóc 
                                    //enti.Get_Time = commentDTO.CreateDate;
                                    //enti.Get_Time_String = commentDTO.CreateDate.ToString("yyyy-MM-dd HH:mm:ss");

                                    string jsonPost1 = KafkaPreview.ToJson<CommentDTO_BigData>(enti);
                                    KafkaPreview kafka1 = new KafkaPreview();
                                    await kafka1.InsertPost(jsonPost1, "crawler-preview-post-comment");
                                    #endregion

                                    indexLastComment++;
                                }
                            }
                            ////Check nút xem thêm
                            //HtmlNode checkMoreItem = _document.DocumentNode.SelectSingleNode("//button[contains(@class,'uitk-button uitk-button-medium uitk-button-has-text uitk-button-secondary')]");
                            //if (checkMoreItem == null)
                            //{
                            //    break;
                            //}
                            //string checkJs = await Common.Utilities.EvaluateJavaScriptSync(_jsClickShowMoreReview, _browser).ConfigureAwait(false);
                            //if (checkJs == null)
                            //{
                            //    break;
                            //}
                            await Task.Delay(TimeSpan.FromSeconds(5));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                string error = ex.Message;
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }
            return commentList;
        }
    }
}
