﻿using CefSharp.WinForms;
using HtmlAgilityPack;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using VCCorp.PreviewCore.Common;
using VCCorp.PreviewCore.DAO;
using VCCorp.PreviewCore.DTO;
using VCCorp.PreviewCore.Kafka;
using static VCCorp.PreviewCore.Data.DataVnTrip;

namespace VCCorp.PreviewCore.BUS
{
    public class ParserVnTrip
    {
        private ChromiumWebBrowser _browser = null;
        private readonly HtmlAgilityPack.HtmlDocument _document = new HtmlAgilityPack.HtmlDocument();
        private const string _jsClickShowMoreReview = @"document.getElementsByClassName('ant-pagination-item-link')[1].click()";
        private const string _jsClickShowMoreReview2 = @"document.getElementsByClassName('ant-pagination-item-link')[2].click()";
        private const string _jsAutoScroll = @"function pageScroll() {window.scrollBy(0,10);scrolldelay = setTimeout(pageScroll,30);}{window.scrollBy(0,10);scrolldelay = setTimeout(pageScroll,30);}";
        private string URL_VNTRIP = "https://www.vntrip.vn";

        public ParserVnTrip()
        {
        }
        public ParserVnTrip(ChromiumWebBrowser browser)
        {
            _browser = browser;
        }

        public async Task<string> CrawlDataPost(string Url, int id)
        {
            string message = "";
            try
            {
                await GetListPost(Url, id);
                CategoryDAO categoryDAO = new CategoryDAO(ConnectionDAO.ConnectionToTableLinkProduct);
                await categoryDAO.UpdateStatusAndDateCategoryById(id);
                categoryDAO.Dispose();
            }
            catch (Exception ex)
            {
                message = ex.Message;
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }
            return message;
        }
        
        public async Task<string> CrawlDetailPost(int id)
        {
            string message = "";
            try
            {
                await GetPostDetail(id);
            }
            catch (Exception ex)
            {
                message = ex.Message;
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }
            return message;
        }

        /// <summary>
        /// Lấy list hotel
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>

        public async Task<List<ArticleDTO>> GetListPost(string keyword, int categoryId)
        {
            List<ArticleDTO> contentList = new List<ArticleDTO>();

            for (int i = 1; i < 10; i++)
            {
                string myJsonResponse = await CallApi(keyword,i);
                Root result = JsonConvert.DeserializeObject<Root>(myJsonResponse);
                try
                {
                    if (result == null)
                    {
                        return contentList;
                    }
                    else
                    {
                        if (result.data.Count > 0)
                        {
                            List<ArticleDTO> lisToReturn = new List<ArticleDTO>();
                            ArticleDAO msql = new ArticleDAO(ConnectionDAO.ConnectionToTableLinkProduct);
                            foreach (var item in result.data)
                            {
                                string link = $"https://www.vntrip.vn/hotel/vn/{item.vntrip_id}?checkInDate=date&nights=1";
                                ArticleDTO obj = new ArticleDTO();
                                obj.Url = link;
                                obj.CreatedDate = DateTime.Now; // ngày bóc tách
                                obj.CreateDate_Timestamp = Common.Utilities.DateTimeToUnixTimestamp(DateTime.Now); // ngày bóc tách chuyển sang dạng Timestamp
                                obj.DomainName = URL_VNTRIP;
                                obj.Title = item.name_vi;
                                obj.Status = 0;
                                lisToReturn.Add(obj);
                                await msql.InsertArticle(obj, categoryId);
                            }
                            msql.Dispose();
                        }
                    }
                }
                catch(Exception ex)
                {
                    var type = this.GetType().Name;
                    Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
                }
            }
            return contentList;
        }

        /// <summary>
        /// Lấy nội dung bình luận
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        public async Task<List<DTO.CommentDTO>> GetPostDetail(int categoryId)
        {
            List<DTO.CommentDTO> commentList = new List<DTO.CommentDTO>();
            try
            {
                ArticleDAO contentDAO = new ArticleDAO(ConnectionDAO.ConnectionToTableLinkProduct);
                List<ContentDTO> dataUrl = contentDAO.GetLinkByCategoryId(categoryId);
                contentDAO.Dispose();
                for (int i = 0; i < dataUrl.Count; i++)
                {
                    int status = dataUrl[i].Status;
                    if (status == 0)// check xem đã bóc hay chưa?
                    {
                        string url = dataUrl[i].ReferUrl;
                        string referUrl = dataUrl[i].ReferUrl;
                        //string url = "https://www.vntrip.vn/hotel/vn/kieu-anh-hotel-11384?checkInDate=20221202&nights=1";
                        await _browser.LoadUrlAsync(url);
                        await Task.Delay(TimeSpan.FromSeconds(10));
                        await Common.Utilities.EvaluateJavaScriptSync("pageScroll = null", _browser).ConfigureAwait(false);
                        await Common.Utilities.EvaluateJavaScriptSync(_jsAutoScroll, _browser).ConfigureAwait(false);
                        await Task.Delay(TimeSpan.FromSeconds(20));

                        string html = await Common.Utilities.GetBrowserSource(_browser).ConfigureAwait(false);
                        _document.LoadHtml(html);
                        html = null;

                        //Lấy hotel details
                        ContentDTO content = new ContentDTO();
                        content.TotalPoint = _document.DocumentNode.SelectSingleNode("//div[contains(@class,'hotelDetail__rate')]//span")?.InnerText;
                        content.Subject = _document.DocumentNode.SelectSingleNode("//h1[contains(@class,'hotelName')]")?.InnerText;
                        content.Contents = Common.Utilities.RemoveSpecialCharacter(_document.DocumentNode.SelectSingleNode("//div[contains(@class,'pText')]//p")?.InnerText);
                        content.ImageThumb = _document.DocumentNode.SelectSingleNode("//div[contains(@class,'hotelDetail__body')]//img")?.Attributes["src"]?.Value ?? "";
                        content.Domain = URL_VNTRIP;
                        content.ReferUrl = url;
                        content.CreateDate = DateTime.Now;

                        ////Lưu vào Db
                        //ContentDAO msql = new ContentDAO(ConnectionDAO.ConnectionToTableLinkProduct);
                        //await msql.InserContent(content);
                        //msql.Dispose();

                        //Update Status (crawled == 1 )
                        ArticleDAO msql1 = new ArticleDAO(ConnectionDAO.ConnectionToTableLinkProduct);
                        await msql1.UpdateStatus(dataUrl[i].ReferUrl, content.Contents);
                        msql1.Dispose();

                        #region gửi đi cho ILS

                        ArticleDTO_BigData ent = new ArticleDTO_BigData();

                        ent.Id = Common.Utilities.Md5Encode(content.Id);
                        ent.Content = content.Contents;

                        //Get_Time là thời gian bóc 
                        ent.Get_Time = content.CreateDate;
                        ent.Get_Time_String = content.CreateDate.ToString("yyyy-MM-dd HH:mm:ss");

                        ent.Description = content.Summary;

                        ent.Title = content.Subject;
                        ent.Url = content.ReferUrl;
                        ent.Source_Id = "0";
                        ent.Category = content.Category;
                        ent.Image = content.ImageThumb;
                        ent.urlAmphtml = "";

                        ent.ContentNoRemoveHtml = ""; // xóa đi khi lưu xuống cho nhẹ

                        string jsonPost = KafkaPreview.ToJson<ArticleDTO_BigData>(ent);
                        KafkaPreview kafka = new KafkaPreview();
                        await kafka.InsertPost(jsonPost, "crawler-preview-post");
                        #endregion

                        while (true)
                        {
                            string html1 = await Common.Utilities.GetBrowserSource(_browser).ConfigureAwait(false);
                            _document.LoadHtml(html1);
                            html1 = null;
                            //Lấy list comment
                            HtmlNodeCollection divComment = _document.DocumentNode.SelectNodes("//li[contains(@class,'hotelFeedback__item')]");
                            if (divComment != null)
                            {
                                foreach (HtmlNode item in divComment)
                                {
                                    DTO.CommentDTO commentDTO = new DTO.CommentDTO();
                                    commentDTO.Author = item.SelectSingleNode(".//p[contains(@class,'p1')]")?.InnerText;
                                    commentDTO.Point = item.SelectSingleNode(".//div[contains(@class,'ratePoint__numb')]/span")?.InnerText;
                                    string comment1 = Regex.Match(Common.Utilities.RemoveSpecialCharacter(item.SelectSingleNode(".//p[contains(@class,'hotelFeedback__text')][1]")?.InnerText), @"(?<=&nbsp;)[\s\S]+").Value;
                                    string comment2 = Regex.Match(Common.Utilities.RemoveSpecialCharacter(item.SelectSingleNode(".//p[contains(@class,'hotelFeedback__text')][2]")?.InnerText), @"(?<=&nbsp;)[\s\S]+").Value;

                                    commentDTO.ContentsComment = comment1 + "." + comment2;
                                    DateTime postDate = DateTime.Now;
                                    string datecomment = item.SelectSingleNode(".//p[contains(@class,'p2')]").InnerText;
                                    if (!string.IsNullOrEmpty(datecomment))
                                    {
                                        Common.DateTimeFormatAgain dtFomat = new Common.DateTimeFormatAgain();
                                        string date = dtFomat.GetDate(datecomment, "dd/MM/yyyy");
                                        try
                                        {
                                            postDate = Convert.ToDateTime(date);
                                        }
                                        catch(Exception ex) {
                                            var type = this.GetType().Name;
                                            Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
                                        }
                                    }
                                    commentDTO.PostDate = postDate;
                                    commentDTO.CreateDate = DateTime.Now;
                                    commentDTO.Domain = URL_VNTRIP;
                                    commentDTO.ReferUrl = url;
                                    commentList.Add(commentDTO);

                                    //Lưu về db
                                    //ArticleDAO msql2 = new ArticleDAO(ConnectionDAO.ConnectionToTableLinkProduct);
                                    //await msql2.UpdateStatus(dataUrl[i].ReferUrl, content.Contents);
                                    //msql2.Dispose();

                                    #region gửi đi cho ILS

                                    CommentDTO_BigData enti = new CommentDTO_BigData();
                                    enti.post_Id = ent.Id;
                                    enti.Comment = commentDTO.ContentsComment;
                                    enti.Author = commentDTO.Author;
                                    enti.Url = commentDTO.ReferUrl;
                                    // thời gian tạo tin
                                    enti.Create_time = commentDTO.PostDate;
                                    enti.Create_Time_String = commentDTO.PostDate.ToString("yyyy-MM-dd HH:mm:ss");

                                    //Get_Time là thời gian bóc 
                                    enti.Get_Time = commentDTO.CreateDate;
                                    enti.Get_Time_String = commentDTO.CreateDate.ToString("yyyy-MM-dd HH:mm:ss");

                                    string jsonpost1 = KafkaPreview.ToJson<CommentDTO_BigData>(enti);
                                    KafkaPreview kafka1 = new KafkaPreview();
                                    await kafka1.InsertPost(jsonpost1, "crawler-preview-post-comment");
                                    #endregion

                                }
                            }

                            //Check nút xem thêm
                            HtmlNode checkMoreItem = _document.DocumentNode.SelectSingleNode("//span[contains(@class,'ant-pagination-item-ellipsis')]");
                            HtmlNode checkEnd = _document.DocumentNode.SelectSingleNode("//li[contains(@class,'ant-pagination-next')]/button[@disabled]");
                            if (checkMoreItem == null)
                            {
                                if (checkEnd != null)
                                {
                                    break;
                                }
                                else
                                {
                                    string checkJs = await Common.Utilities.EvaluateJavaScriptSync(_jsClickShowMoreReview, _browser).ConfigureAwait(false);
                                    if (checkJs == null)
                                    {
                                        break;
                                    }
                                    await Task.Delay(TimeSpan.FromSeconds(5));
                                }
                            }
                            else
                            {
                                if (checkEnd != null)
                                {
                                    break;
                                }
                                else
                                {
                                    string checkJs1 = await Common.Utilities.EvaluateJavaScriptSync(_jsClickShowMoreReview2, _browser).ConfigureAwait(false);
                                    if (checkJs1 == null)
                                    {
                                        break;
                                    }
                                    await Task.Delay(TimeSpan.FromSeconds(5));
                                }
                            }
                        }
                    }

                }
            }
            catch(Exception ex) {
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }
            return commentList;
        }

        public async Task<string> CallApi(string keyword, int page)
        {
            string html = "";
            DateTime date = DateTime.Now;
            string dateStr = date.Year.ToString() + (date.Month > 9 ? date.Month.ToString() : "0" + date.Month.ToString()) + date.Day.ToString();
            HttpClient client = new HttpClient();
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, $"https://micro-services.vntrip.vn/search-engine/search/vntrip-hotel-availability/?seo_code={keyword}&check_in_date={dateStr}&nights=1&page_size=20&page={page}&request_source=web_frontend");
            request.Headers.Add("authority", "micro-services.vntrip.vn");
            request.Headers.Add("path", "/search-engine/search/vntrip-hotel-availability/?seo_code=quang-nam&check_in_date=20230309&nights=1&page_size=20&page=1&request_source=web_frontend");
            request.Headers.Add("origin", "https://www.vntrip.vn");
            request.Headers.Add("referer", "https://www.vntrip.vn");
            request.Headers.Add("user-agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36");
            try
            {
                HttpResponseMessage response = await client.SendAsync(request);
                html = await response.Content.ReadAsStringAsync();
            }
            catch (Exception ex)
            {
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }
            return html;
        }
    }
}
