﻿using CefSharp.WinForms;
using HtmlAgilityPack;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using VCCorp.PreviewCore.Common;
using VCCorp.PreviewCore.DAO;
using VCCorp.PreviewCore.DTO;
using VCCorp.PreviewCore.Kafka;

namespace VCCorp.PreviewCore.BUS
{
    public class ParserAirbnb
    {
        private ChromiumWebBrowser _browser = null;
        private readonly HtmlAgilityPack.HtmlDocument _document = new HtmlAgilityPack.HtmlDocument();
        private string URL_AIRBNB = "https://www.airbnb.com.vn";
        private ConcurrentQueue<ContentDTO> _myQueue = new ConcurrentQueue<ContentDTO>();
        private const string _jsAutoScroll = @"function pageScroll() {window.scrollBy(0,10);scrolldelay = setTimeout(pageScroll,50);}{window.scrollBy(0,10);scrolldelay = setTimeout(pageScroll,50);}";
        private const string _jsClickNextPage = @"document.getElementsByClassName('_1bfat5l l1j9v1wn dir dir-ltr')[0].click()";
        private const string _jsScroll = @"window.scrollTo(0, document.body.scrollHeight/1)";

        public ParserAirbnb()
        {
        }
        public ParserAirbnb(ChromiumWebBrowser browser)
        {
            _browser = browser;
        }

        public async Task<string> CrawlDataPost(string Url, int id)
        {
            string message = "";
            try
            {
                await GetListPost(Url, id);
                CategoryDAO categoryDAO = new CategoryDAO(ConnectionDAO.ConnectionToTableLinkProduct);
                await categoryDAO.UpdateStatusAndDateCategoryById(id);
                categoryDAO.Dispose();
            }
            catch (Exception ex)
            {
                message = ex.Message;
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }
            return message;
        }

        public async Task<string> CrawlDetailPost(int id)
        {
            string message = "";
            try
            {
                await GetPostDetail(id);
            }
            catch (Exception ex)
            {
                message = ex.Message;
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }
            return message;
        }

        /// <summary>
        /// Lấy list hotel
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        public async Task<List<ArticleDTO>> GetListPost(string url, int categoryId)
        {
            List<ArticleDTO> contentList = new List<ArticleDTO>();
           
            try
            {
                await _browser.LoadUrlAsync(url);
                await Task.Delay(TimeSpan.FromSeconds(10));
                //await Common.Utilities.EvaluateJavaScriptSync(_jsAutoScroll, _browser).ConfigureAwait(false);
                //await Task.Delay(TimeSpan.FromMinutes(2));
                ushort scroll = 0;
                ushort indexLastContent = 0;
                while (true)
                {
                    indexLastContent = 0;
                    scroll = 0;
                    while (scroll <= 5)
                    {
                        await Common.Utilities.EvaluateJavaScriptSync(_jsScroll, _browser).ConfigureAwait(false);
                        await Task.Delay(TimeSpan.FromSeconds(2));
                        scroll++;
                    }
                    string html = await Common.Utilities.GetBrowserSource(_browser).ConfigureAwait(false);
                    _document.LoadHtml(html);
                    html = null;

                    HtmlNodeCollection divComment = _document.DocumentNode.SelectNodes($"//div[contains(@class,'gh7uyir')]/div/div[contains(@class,' dir dir-ltr')][position()>{indexLastContent}]");
                    HtmlNode nextPage = _document.DocumentNode.SelectSingleNode($"//button[contains(@class,'_1bfat5l l1j9v1wn dir dir-ltr')][@disabled]");
                    if (divComment == null)
                    {
                        continue;
                    }
                    else
                    {
                        foreach (HtmlNode item in divComment)
                        {
                            string listURL = item.SelectSingleNode(".//div[contains(@class,'cy5jw6o')]/a")?.Attributes["href"]?.Value ?? "";
                            //loại bỏ kí tự đằng sau dấu '?' chỉ lấy id hotel
                            listURL = Regex.Replace(listURL, @"\?[\s\S]+", " ", RegexOptions.IgnoreCase);
                            if (string.IsNullOrEmpty(listURL))
                            {
                                break;
                            }
                            //loại bỏ kí tự đằng sau dấu '?' chỉ lấy id hotel
                            //listURL = Regex.Replace(listURL, @"\?[\s\S]+", " ", RegexOptions.IgnoreCase);
                            ArticleDTO content = new ArticleDTO();
                            content.Url = listURL;
                            content.CreatedDate = DateTime.Now; // ngày bóc tách
                            content.CreateDate_Timestamp = Common.Utilities.DateTimeToUnixTimestamp(DateTime.Now); // ngày bóc tách chuyển sang dạng Timestamp
                            content.DomainName = URL_AIRBNB;
                            content.Title = item.SelectSingleNode(".//div[contains(@class,'g1qv1ctd cb4nyux dir dir-ltr')]//div[contains(@class,'t1jojoys dir dir-ltr')]")?.InnerText ?? "";
                            content.Status = 0;
                            contentList.Add(content);

                            ArticleDAO msql1 = new ArticleDAO(ConnectionDAO.ConnectionToTableLinkProduct);
                            await msql1.InsertArticle(content, categoryId);
                            msql1.Dispose();

                            indexLastContent++;
                        }
                    }
                    string checkjs = await Common.Utilities.EvaluateJavaScriptSync(_jsClickNextPage, _browser).ConfigureAwait(false);
                    if (checkjs == null)
                    {
                        break;
                    }
                    if (nextPage != null)
                    {
                        break;
                    }
                    await Task.Delay(TimeSpan.FromSeconds(10));
                }
            }
            catch(Exception ex) {
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }
            return contentList;
        }


        /// <summary>
        /// Lấy nội dung bài viết + bình luận
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        public async Task<List<DTO.PostDTO>> GetPostDetail(int categoryId)
        {
            List<DTO.PostDTO> commentList = new List<DTO.PostDTO>();
            try
            {
                //Lấy list Url hotel từ Db
                ArticleDAO contentDAO = new ArticleDAO(ConnectionDAO.ConnectionToTableLinkProduct);
                List<ContentDTO> dataUrl = contentDAO.GetLinkByCategoryId(categoryId);
                contentDAO.Dispose();

                //Đọc từng Url
                for (int i = 0; i < dataUrl.Count; i++)
                {
                    string url = URL_AIRBNB + dataUrl[i].ReferUrl;
                    await _browser.LoadUrlAsync(url);
                    await Task.Delay(TimeSpan.FromSeconds(10));

                    string html = await Common.Utilities.GetBrowserSource(_browser).ConfigureAwait(false);
                    _document.LoadHtml(html);
                    html = null;

                    // Lấy detail content hotel
                    ContentDTO content = new ContentDTO();
                    content.TotalPoint = _document.DocumentNode.SelectSingleNode("//div[contains(@class,'_1qdp1ym')]//span[contains(@class,'_17p6nbba')]")?.InnerText;
                    content.Subject = _document.DocumentNode.SelectSingleNode("//div[contains(@class,'_b8stb0')]//h1[contains(@class,'_fecoyn4')]")?.InnerText;
                    if (url.Contains("luxury"))
                    {
                        content.Contents = Common.Utilities.RemoveSpecialCharacter(_document.DocumentNode.SelectSingleNode("//div[contains(@class,'c1yo0219 dir dir-ltr')]//div[contains(@data-section-id,'UNSTRUCTURED_DESCRIPTION_LUXE')]")?.InnerText);
                        content.Summary = _document.DocumentNode.SelectSingleNode("//div[contains(@class,'_8gyrpf')]//h2")?.InnerText;
                    }
                    if (url.Contains("rooms"))
                    {
                        var a = _document.DocumentNode.SelectSingleNode("//div[contains(@class,'c1yo0219 dir dir-ltr')]//div[contains(@class,'d1isfkwk dir dir-ltr')]//span[contains(@class,'ll4r2nl dir dir-ltr')]")?.InnerText;
                        content.Contents = Common.Utilities.RemoveSpecialCharacter(_document.DocumentNode.SelectSingleNode("//div[contains(@class,'c1yo0219 dir dir-ltr')]//div[contains(@class,'d1isfkwk dir dir-ltr')]//span[contains(@class,'ll4r2nl dir dir-ltr')]")?.InnerText);
                        content.Summary = _document.DocumentNode.SelectSingleNode("//div[contains(@class,'_cv5qq4')]//h2")?.InnerText;
                    }
                    content.ImageThumb = _document.DocumentNode.SelectSingleNode("//div[contains(@class,'_1h6n1zu')]//img")?.Attributes["src"]?.Value ?? "";
                    content.Domain = URL_AIRBNB;
                    content.ReferUrl = url;
                    content.CreateDate = DateTime.Now;

                    if (content.Subject != null)
                    {
                        //Lưu vào Db
                        ArticleDAO msqlUpdate = new ArticleDAO(ConnectionDAO.ConnectionToTableLinkProduct);
                        await msqlUpdate.UpdateStatus(dataUrl[i].ReferUrl, content.Contents);
                        msqlUpdate.Dispose();

                        #region gửi đi cho ILS
                        ArticleDTO_BigData ent = new ArticleDTO_BigData();
                        ent.Id = Common.Utilities.Md5Encode(url);
                        ent.Content = content.Contents;
                        //Get_Time là thời gian bóc 
                        ent.Get_Time = content.CreateDate;
                        ent.Get_Time_String = content.CreateDate.ToString("yyyy-MM-dd HH:mm:ss");
                        ent.Description = content.Summary;
                        ent.Title = content.Subject;
                        ent.Url = content.ReferUrl;
                        ent.Source_Id = "0";
                        ent.Category = content.Category;
                        ent.Image = content.ImageThumb;
                        ent.urlAmphtml = "";
                        ent.ContentNoRemoveHtml = ""; // xóa đi khi lưu xuống cho nhẹ

                        string jsonPost = KafkaPreview.ToJson<ArticleDTO_BigData>(ent);
                        KafkaPreview kafka = new KafkaPreview();
                        await kafka.InsertPost(jsonPost, "crawler-preview-post");
                        #endregion

                        //Lấy list comment
                        HtmlNodeCollection divComment = _document.DocumentNode.SelectNodes("//div[contains(@class,'r1rl3yjt')]");
                        if (divComment != null)
                        {
                            foreach (HtmlNode item in divComment)
                            {
                                DTO.CommentDTO commentDTO = new DTO.CommentDTO();
                                commentDTO.Author = item.SelectSingleNode(".//div[contains(@class,'t9gtck5')]/h3")?.InnerText;
                                if(commentDTO.Author == null || commentDTO.Author == "")
                                {
                                    commentDTO.Author = item.SelectSingleNode(".//div[contains(@class,'t11wgnhd dir dir-ltr')]//h3")?.InnerText;
                                }
                                commentDTO.ContentsComment = Common.Utilities.RemoveSpecialCharacter(item.SelectSingleNode(".//span[contains(@class,'ll4r2nl')]")?.InnerText);
                                DateTime postDate = DateTime.Now;
                                string datecomment = item.SelectSingleNode(".//li[contains(@class,'_1f1oir5')]").InnerText;
                                if (!string.IsNullOrEmpty(datecomment))
                                {
                                    Common.DateTimeFormatAgain dtFomat = new Common.DateTimeFormatAgain();
                                    string date = dtFomat.GetDateByPattern(datecomment, "MM/yyyy");
                                    try
                                    {
                                        postDate = Convert.ToDateTime(date);
                                    }
                                    catch(Exception ex) {
                                        var type = this.GetType().Name;
                                        Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
                                    }
                                }
                                commentDTO.PostDate = postDate;
                                commentDTO.CreateDate = DateTime.Now;
                                commentDTO.Domain = URL_AIRBNB;
                                commentDTO.ReferUrl = url;
                                //commentList.Add(commentDTO);

                                //Lưu vào Db
                                //CommentDAO msql1 = new CommentDAO(ConnectionDAO.ConnectionToTableLinkProduct);
                                //await msql1.InsertListComment(commentDTO);
                                //msql1.Dispose();

                                #region gửi đi cho ILS

                                CommentDTO_BigData enti = new CommentDTO_BigData();
                                enti.post_Id = Common.Utilities.Md5Encode(url);
                                enti.Comment = commentDTO.ContentsComment;
                                enti.Author = commentDTO.Author;
                                enti.Url = commentDTO.ReferUrl;
                                // thời gian tạo tin
                                enti.Create_time = commentDTO.PostDate;
                                enti.Create_Time_String = commentDTO.PostDate.ToString("yyyy-MM-dd HH:mm:ss");

                                //Get_Time là thời gian bóc 
                                enti.Get_Time = commentDTO.CreateDate;
                                enti.Get_Time_String = commentDTO.PostDate.ToString("yyyy-MM-dd HH:mm:ss");

                                string jsonPost1 = KafkaPreview.ToJson<CommentDTO_BigData>(enti);
                                KafkaPreview kafka1 = new KafkaPreview();
                                await kafka1.InsertPost(jsonPost1, "crawler-preview-post-comment");
                                #endregion
                            }
                        }
                        await Task.Delay(TimeSpan.FromSeconds(5));
                    }
                }
            }
            catch(Exception ex) {
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }
            return commentList;
        }
    }
}
