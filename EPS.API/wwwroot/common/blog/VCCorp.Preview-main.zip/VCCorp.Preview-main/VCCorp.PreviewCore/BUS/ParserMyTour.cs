﻿using CefSharp.WinForms;
using HtmlAgilityPack;
using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using VCCorp.PreviewCore.Common;
using VCCorp.PreviewCore.DAO;
using VCCorp.PreviewCore.DTO;
using VCCorp.PreviewCore.Kafka;

namespace VCCorp.PreviewCore.BUS
{
    public class ParserMyTour
    {
        private ChromiumWebBrowser _browser = null;
        private readonly HtmlAgilityPack.HtmlDocument _document = new HtmlAgilityPack.HtmlDocument();
        private const string _jsClickShowMoreReview = @"document.getElementsByClassName('MuiButtonBase-root MuiButton-root MuiButton-text jss243')[0].click()";
        private const string _jsAutoScroll = @"function pageScroll() {window.scrollBy(0,10);scrolldelay = setTimeout(pageScroll,30);}{window.scrollBy(0,10);scrolldelay = setTimeout(pageScroll,30);}";
        private string URL_MYTOUR = "https://mytour.vn";
        private const string _jsScroll = @"window.scrollTo(0, document.body.scrollHeight/1)";
        private List<string> _jsClickShowMoreHotels = new List<string>()
        {
            @"document.getElementsByClassName('MuiButtonBase-root MuiButton-root MuiButton-text jss268')[0].click()",
            @"document.getElementsByClassName('MuiButtonBase-root MuiButton-root MuiButton-text jss270')[0].click()",
            @"document.getElementsByClassName('MuiButtonBase-root MuiButton-root MuiButton-text jss269')[0].click()",
            @"document.getElementsByClassName('MuiButtonBase-root MuiButton-root MuiButton-text jss262')[0].click()",
            @"document.getElementsByClassName('MuiButtonBase-root MuiButton-root MuiButton-text jss261')[0].click()",
            @"document.getElementsByClassName('sss')[0].click()",
            @"document.getElementsByClassName('MuiButtonBase-root MuiButton-root MuiButton-text jss264')[0].click()",
            @"document.getElementsByClassName('MuiButtonBase-root MuiButton-root MuiButton-text jss268')[0].click()",
            @"document.getElementsByClassName('MuiButtonBase-root MuiButton-root MuiButton-text jss269')[0].click()",
            @"document.getElementsByClassName('MuiButtonBase-root MuiButton-root MuiButton-text jss269')[0].click()",
            @"document.getElementsByClassName('sss')[0].click()",
            @"document.getElementsByClassName('sss')[0].click()",
        };
        public ParserMyTour(ChromiumWebBrowser browser)
        {
            _browser = browser;
        }

        public async Task<string> CrawlDataPost(string Url, int id, int count)
        {
            string message = "";
            try
            {
                string _jsClickShowMoreHotel = "";
                _jsClickShowMoreHotel = _jsClickShowMoreHotels[count];
                await GetListPost(Url, id, _jsClickShowMoreHotel);
                CategoryDAO categoryDAO = new CategoryDAO(ConnectionDAO.ConnectionToTableLinkProduct);
                await categoryDAO.UpdateStatusAndDateCategoryById(id);
                categoryDAO.Dispose();
            }
            catch (Exception ex)
            {
                message = ex.Message;
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }
            return message;
        }

        public async Task<string> CrawlDetailPost(int id)
        {
            string message = "";
            try
            {
                await GetPostDetail(id);
            }
            catch (Exception ex)
            {
                message = ex.Message;
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }
            return message;
        }

        /// <summary>
        /// Lấy list hotel
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        public async Task<List<ArticleDTO>> GetListPost(string url, int categoryId, string _jsClickShowMoreHotel)
        {
            List<ArticleDTO> contentList = new List<ArticleDTO>();
            ushort indexLastContent = 0;
            ushort scroll = 0;
            try
            {
                await _browser.LoadUrlAsync(url);
                await Task.Delay(TimeSpan.FromSeconds(10));
                await Common.Utilities.EvaluateJavaScriptSync(_jsAutoScroll, _browser).ConfigureAwait(false);
                await Task.Delay(TimeSpan.FromSeconds(20));
                indexLastContent = 0;
                scroll = 0;
                while (scroll <= 5)
                {
                    await Common.Utilities.EvaluateJavaScriptSync(_jsScroll, _browser).ConfigureAwait(false);
                    await Task.Delay(TimeSpan.FromSeconds(2));
                    scroll++;
                }
                string checkJs1 = await Common.Utilities.EvaluateJavaScriptSync(_jsClickShowMoreHotel, _browser).ConfigureAwait(false);
                await Task.Delay(TimeSpan.FromMinutes(1));
                while (true)
                {
                    string html = await Common.Utilities.GetBrowserSource(_browser).ConfigureAwait(false);
                    _document.LoadHtml(html);
                    html = null;

                    HtmlNodeCollection divComment = _document.DocumentNode.SelectNodes($"//div[contains(@class,'item-hotel-listing')][position()>{indexLastContent}]");
                    if (divComment == null)
                    {
                        continue;
                    }

                    if (divComment != null)
                    {
                        foreach (HtmlNode item in divComment)
                        {
                            string listURL = item.SelectSingleNode(".//a[contains(@class,'MuiLink-root')]")?.Attributes["href"]?.Value ?? "";
                            //loại bỏ kí tự đằng sau dấu '?' chỉ lấy id hotel
                            listURL = Regex.Replace(listURL, @"\?[\s\S]+", " ", RegexOptions.IgnoreCase);
                            ArticleDTO content = new ArticleDTO();
                            content.Url = listURL;
                            content.CreatedDate = DateTime.Now; // ngày bóc tách
                            content.CreateDate_Timestamp = Common.Utilities.DateTimeToUnixTimestamp(DateTime.Now); // ngày bóc tách chuyển sang dạng Timestamp
                            content.DomainName = URL_MYTOUR;
                            content.Title = item.SelectSingleNode(".//h3[contains(@class,'MuiBox-root')]")?.InnerText ?? "";
                            content.Status = 0;
                            contentList.Add(content);

                            ArticleDAO msql = new ArticleDAO(ConnectionDAO.ConnectionToTableLinkProduct);
                            await msql.InsertArticle(content, categoryId);
                            msql.Dispose();

                            indexLastContent++;
                        }
                    }
                    //string checkJs = await Common.Utilities.EvaluateJavaScriptSync(_jsAutoScroll, _browser).ConfigureAwait(false);
                    //if (checkJs == null)
                    //{
                    //    break;
                    //}
                    //await Task.Delay(15_000);

                    //string checkJs1 = await Common.Utilities.EvaluateJavaScriptSync(_jsClickShowMoreReview, _browser).ConfigureAwait(false);
                    //if (checkJs == null)
                    //{
                    //    break;
                    //}

                    await Task.Delay(TimeSpan.FromSeconds(10));
                }
            }
            catch (Exception ex)
            {
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }
            return contentList;
        }

        /// <summary>
        /// Lấy nội dung bài viết và nội dung bình luận
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        public async Task<List<DTO.CommentDTO>> GetPostDetail(int categoryId)
        {
            List<DTO.CommentDTO> commentList = new List<DTO.CommentDTO>();
            try
            {
                //Lấy url hotel từ db
                ArticleDAO contentDAO = new ArticleDAO(ConnectionDAO.ConnectionToTableLinkProduct);
                List<ContentDTO> dataUrl = contentDAO.GetLinkByCategoryId(categoryId);
                contentDAO.Dispose();

                //Đọc từng url để bóc
                for (int i = 0; i < dataUrl.Count; i++)
                {
                    int status = dataUrl[i].Status;
                    if (status == 0)// check xem đã bóc hay chưa?
                    {
                        string url = URL_MYTOUR + dataUrl[i].ReferUrl;
                        string referUrl = dataUrl[i].ReferUrl;
                        await _browser.LoadUrlAsync(url);
                        await Task.Delay(TimeSpan.FromSeconds(10));
                        await Common.Utilities.EvaluateJavaScriptSync(_jsAutoScroll, _browser).ConfigureAwait(false);
                        await Task.Delay(TimeSpan.FromSeconds(20));
                        string html = await Common.Utilities.GetBrowserSource(_browser).ConfigureAwait(false);
                        _document.LoadHtml(html);
                        html = null;

                        //Bóc hotel detail
                        ContentDTO content = new ContentDTO();
                        content.Subject = _document.DocumentNode.SelectSingleNode("//div[(@id='rooms_overview')]//h1")?.InnerText;
                        content.ImageThumb = _document.DocumentNode.SelectSingleNode("//div[contains(@id,'id-hotel-detail')]//img")?.Attributes["src"]?.Value ?? "";
                        content.Domain = URL_MYTOUR;
                        content.ReferUrl = url;
                        content.Contents = _document.DocumentNode.SelectSingleNode("//div[contains(@class,'MuiBox-root')]//ul//li")?.InnerText;
                        content.CreateDate = DateTime.Now;
                        content.Category = _document.DocumentNode.SelectSingleNode("//div[contains(@class,'MuiBox-root')]//div[contains(@class,'MuiBox-root')]//span[contains(@class,'MuiBox-root jss201 jss191 ')]")?.InnerText;
                        #region gửi đi cho ILS

                        ArticleDTO_BigData ent = new ArticleDTO_BigData();

                        ent.Id = Common.Utilities.Md5Encode(content.Id);
                        ent.Content = content.Contents;

                        //Get_Time là thời gian bóc 
                        ent.Get_Time = content.CreateDate;
                        ent.Get_Time_String = content.CreateDate.ToString("yyyy-MM-dd HH:mm:ss");

                        ent.Description = content.Summary;

                        ent.Title = content.Subject;
                        ent.Url = content.ReferUrl;
                        ent.Source_Id = "0";
                        ent.Category = content.Category;
                        ent.Image = content.ImageThumb;
                        ent.urlAmphtml = "";

                        ent.ContentNoRemoveHtml = ""; // xóa đi khi lưu xuống cho nhẹ

                        string jsonPost = KafkaPreview.ToJson<ArticleDTO_BigData>(ent);
                        KafkaPreview kafka = new KafkaPreview();
                        await kafka.InsertPost(jsonPost, "crawler-preview-post"); ;
                        #endregion

                        //Bóc list cmt
                        HtmlNodeCollection divComment = _document.DocumentNode.SelectNodes("//div[contains(@class,'jss2')]//div[contains(@class,'MuiGrid-container')]");
                        HtmlNode checkBtnLoadMore = _document.DocumentNode.SelectSingleNode("//div[contains(@id,'evaluate')]//div[3]//div[8]/div");

                        if (divComment != null)
                        {
                            foreach (HtmlNode item in divComment)
                            {
                                DTO.CommentDTO commentDTO = new DTO.CommentDTO();
                                commentDTO.Author = item.SelectSingleNode("./div/div/div[2]/span")?.InnerText;
                                commentDTO.Point = item.SelectSingleNode("./div[2]/div[1]/div[1]/p")?.InnerText;
                                commentDTO.ContentsComment = Common.Utilities.RemoveSpecialCharacter(item.SelectSingleNode("./div[2]/div[1]/div[2]/div[1]")?.InnerText);
                                DateTime postDate = DateTime.Now;
                                string datecomment = item.SelectSingleNode("./div/div/div[2]/div/div[1]/span").InnerText;
                                if (!string.IsNullOrEmpty(datecomment))
                                {
                                    Common.DateTimeFormatAgain dtFomat = new Common.DateTimeFormatAgain();
                                    string date = dtFomat.GetDate(datecomment, "dd/MM/yyyy");

                                    string fulldate = date;

                                    try
                                    {
                                        postDate = Convert.ToDateTime(fulldate);
                                    }
                                    catch (Exception ex)
                                    {
                                        var type = this.GetType().Name;
                                        Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
                                    }
                                }
                                commentDTO.PostDate = postDate;
                                commentDTO.CreateDate = DateTime.Now;
                                commentDTO.Domain = URL_MYTOUR;
                                commentDTO.ReferUrl = url;
                                commentList.Add(commentDTO);

                                //Update Status (crawled == 1 )
                                ArticleDAO msql1 = new ArticleDAO(ConnectionDAO.ConnectionToTableLinkProduct);
                                await msql1.UpdateStatus(referUrl, content.Contents);
                                msql1.Dispose();

                                #region gửi đi cho ILS

                                CommentDTO_BigData enti = new CommentDTO_BigData();
                                enti.post_Id = ent.Id;
                                enti.Comment = commentDTO.ContentsComment;
                                enti.Author = commentDTO.Author;
                                enti.Url = commentDTO.ReferUrl;
                                // thời gian tạo tin
                                enti.Create_time = commentDTO.PostDate;
                                enti.Create_Time_String = commentDTO.PostDate.ToString("yyyy-MM-dd HH:mm:ss");

                                //Get_Time là thời gian bóc 
                                enti.Get_Time = commentDTO.CreateDate;
                                enti.Get_Time_String = commentDTO.CreateDate.ToString("yyyy-MM-dd HH:mm:ss");

                                string jsonPost1 = KafkaPreview.ToJson<CommentDTO_BigData>(enti);
                                KafkaPreview kafka1 = new KafkaPreview();
                                await kafka1.InsertPost(jsonPost1, "crawler-preview-post-comment");
                                #endregion
                            }
                        }
                        await Task.Delay(TimeSpan.FromSeconds(5));
                    }
                }
            }
            catch (Exception ex)
            {
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }
            return commentList;
        }
    }
}
