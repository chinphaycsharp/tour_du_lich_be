﻿using CefSharp.WinForms;
using HtmlAgilityPack;
using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using VCCorp.PreviewCore.Common;
using VCCorp.PreviewCore.DAO;
using VCCorp.PreviewCore.DTO;
using VCCorp.PreviewCore.Kafka;

namespace VCCorp.PreviewCore.BUS
{
    public class ParserExpedia
    {
        private ChromiumWebBrowser _browser = null;
        private readonly HtmlAgilityPack.HtmlDocument _document = new HtmlAgilityPack.HtmlDocument();
        private const string _jsClickShowMoreReview = @"document.getElementsByClassName('uitk-button uitk-button-medium uitk-button-has-text uitk-button-secondary')[0].click()";
        private const string _jsClickShowMoreHotel = @"document.getElementsByClassName('uitk-button uitk-button-medium uitk-button-secondary')[0].click()";
        private const string _jsClickShowMoreContent = @"document.getElementsByClassName('uitk-link uitk-expando-peek-link uitk-link-align-left uitk-link-layout-default uitk-link-medium')[0].click()";
        private const string _jsScroll = @"window.scrollTo(0, document.body.scrollHeight/1)";
        private const string _jsAutoScroll1 = @"function pageScroll() {window.scrollBy(0,10);scrolldelay = setTimeout(pageScroll,30);}{window.scrollBy(0,10);scrolldelay = setTimeout(pageScroll,30);}";
        private string URL_EXPEDIA = "https://www.expedia.com.vn";

        public ParserExpedia()
        {
        }

        public ParserExpedia(ChromiumWebBrowser browser)
        {
            _browser = browser;
        }

        public async Task<string> CrawlDataPost(string Url, int id)
        {
            string message = "";
            try
            {
                await GetListPost(Url, id);
                CategoryDAO categoryDAO = new CategoryDAO(ConnectionDAO.ConnectionToTableLinkProduct);
                await categoryDAO.UpdateStatusAndDateCategoryById(id);
                categoryDAO.Dispose();
            }
            catch (Exception ex)
            {
                message = ex.Message;
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }
            return message;
        }

        public async Task<string> CrawlDetailPost(int id)
        {
            string message = "";
            try
            {
                await GetPostDetail(id);
            }
            catch (Exception ex)
            {
                message = ex.Message;
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }
            return message;
        }

        /// <summary>
        /// Lấy list hotel
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        public async Task<List<ArticleDTO>> GetListPost(string urlPlace, int categoryId)
        {
            List<ArticleDTO> contentList = new List<ArticleDTO>();
            
            try
            {
                ushort indexLastContent = 0;
                ushort scroll = 0;
                string url = urlPlace;
                await _browser.LoadUrlAsync(url);
                await Task.Delay(TimeSpan.FromSeconds(10));
                //await Common.Utilities.EvaluateJavaScriptSync(_jsAutoScroll1, _browser).ConfigureAwait(false);
                //await Task.Delay(TimeSpan.FromMinutes(2));

                while (true)
                {
                    indexLastContent = 0;
                    scroll = 0;
                    while (scroll <= 5)
                    {
                        await Common.Utilities.EvaluateJavaScriptSync(_jsScroll, _browser).ConfigureAwait(false);
                        await Task.Delay(TimeSpan.FromSeconds(2));
                        scroll++;
                    }
                    string html = await Common.Utilities.GetBrowserSource(_browser).ConfigureAwait(false);
                    _document.LoadHtml(html);
                    html = null;

                    HtmlNodeCollection divComment = _document.DocumentNode.SelectNodes($"//div[contains(@class,'uitk-card uitk-card-roundcorner-all uitk-card-has-primary-theme')][position()>{indexLastContent}]");
                    if (divComment == null)
                    {
                        continue;
                    }
                    else
                    {
                        foreach (HtmlNode item in divComment)
                        {
                            string listURL = item.SelectSingleNode(".//a[contains(@class,'uitk-card-link')]")?.Attributes["href"]?.Value ?? "";
                            //loại bỏ kí tự đằng sau dấu '?' chỉ lấy id hotel
                            listURL = Regex.Replace(listURL, @"\?[\s\S]+", " ", RegexOptions.IgnoreCase);
                            ArticleDTO content = new ArticleDTO();
                            content.Url = listURL;
                            content.CreatedDate = DateTime.Now; // ngày bóc tách
                            content.DomainName = URL_EXPEDIA;
                            content.Title = item.SelectSingleNode(".//a[contains(@class,'uitk-card-link')]//span")?.InnerText ?? "";
                            content.Status = 0;
                            contentList.Add(content);

                            ArticleDAO msql = new ArticleDAO(ConnectionDAO.ConnectionToTableLinkProduct);
                            await msql.InsertArticle(content, categoryId);
                            msql.Dispose();

                            indexLastContent++;
                        }
                    }
                    await Common.Utilities.EvaluateJavaScriptSync("pageScroll = null", _browser).ConfigureAwait(false);
                    string checkJs1 = await Common.Utilities.EvaluateJavaScriptSync(_jsClickShowMoreHotel, _browser).ConfigureAwait(false);
                    if (checkJs1 == null)
                    {
                        break;
                    }
                    await Task.Delay(TimeSpan.FromSeconds(10));
                }
            }
            catch(Exception ex) {
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }
            return contentList;
        }


        /// <summary>
        /// Lấy nội dung bình luận
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        public async Task<List<DTO.CommentDTO>> GetPostDetail(int categoryId)
        {
            List<DTO.CommentDTO> commentList = new List<DTO.CommentDTO>();
            ushort indexLastComment = 0;
            try
            {
                ArticleDAO contentDAO = new ArticleDAO(ConnectionDAO.ConnectionToTableLinkProduct);
                List<ContentDTO> dataUrl = contentDAO.GetLinkByCategoryId(categoryId);
                //byte indexLoadComment = 0;
                contentDAO.Dispose();
                for (int i = 0; i < dataUrl.Count; i++)
                {
                    indexLastComment = 0;
                    //indexLoadComment = 0;
                    int status = dataUrl[i].Status;
                    if (status == 0)// check xem đã bóc hay chưa?
                    {
                        if (dataUrl[i].ReferUrl == "")
                        {
                            continue;
                        }
                        string url = URL_EXPEDIA + dataUrl[i].ReferUrl;
                        await _browser.LoadUrlAsync(url);
                        await Task.Delay(TimeSpan.FromSeconds(10));
                        await Common.Utilities.EvaluateJavaScriptSync("pageScroll = null", _browser).ConfigureAwait(false);
                        await Common.Utilities.EvaluateJavaScriptSync(_jsAutoScroll1, _browser).ConfigureAwait(false);
                        await Task.Delay(TimeSpan.FromSeconds(10));
                        string html = await Common.Utilities.GetBrowserSource(_browser).ConfigureAwait(false);
                        _document.LoadHtml(html);
                        html = null;

                        //await Common.Utilities.EvaluateJavaScriptSync(_jsClickShowMoreContent, _browser).ConfigureAwait(false);
                        //Lấy hotel details
                        ContentDTO content = new ContentDTO();
                        content.Subject = _document.DocumentNode.SelectSingleNode("//div[contains(@class,'uitk-spacing uitk-spacing-padding-small-blockend-four uitk-spacing-padding-large-blockstart-three')]//h1[contains(@class,'uitk-heading uitk-heading-3')]")?.InnerText;
                        content.Contents = _document.DocumentNode.SelectSingleNode("//div[@class='uitk-expando-peek uitk-spacing uitk-spacing-padding-inlinestart- uitk-spacing-padding-blockstart-two']")?.InnerText;
                        content.ImageThumb = _document.DocumentNode.SelectSingleNode("//div[contains(@class,'uitk-image-placeholder')]//img")?.Attributes["src"]?.Value ?? "";
                        content.Domain = URL_EXPEDIA;
                        content.ReferUrl = url;
                        content.CreateDate = DateTime.Now;
                        var category = dataUrl[i].ReferUrl.Split('/')[1];
                        content.Category = category;
                        ////Lưu vào Db
                        //ContentDAO msql = new ContentDAO(ConnectionDAO.ConnectionToTableLinkProduct);
                        //await msql.InserContent(content);
                        //msql.Dispose();

                        //Update Status (crawled == 1 )
                        ArticleDAO msql1 = new ArticleDAO(ConnectionDAO.ConnectionToTableLinkProduct);
                        await msql1.UpdateStatus(dataUrl[i].ReferUrl, content.Contents);
                        msql1.Dispose();

                        #region gửi đi cho ILS

                        ArticleDTO_BigData ent = new ArticleDTO_BigData();

                        ent.Id = Common.Utilities.Md5Encode(url);
                        ent.Content = content.Contents;

                        //Get_Time là thời gian bóc 
                        ent.Get_Time = content.CreateDate;
                        ent.Get_Time_String = content.CreateDate.ToString("yyyy-MM-dd HH:mm:ss");

                        ent.Description = content.Summary;

                        ent.Title = content.Subject;
                        ent.Url = content.ReferUrl;
                        ent.Source_Id = "0";
                        ent.Category = content.Category;
                        ent.Image = content.ImageThumb;
                        ent.urlAmphtml = "";

                        ent.ContentNoRemoveHtml = ""; // xóa đi khi lưu xuống cho nhẹ

                        string jsonPost = KafkaPreview.ToJson<ArticleDTO_BigData>(ent);
                        KafkaPreview kafka = new KafkaPreview();
                        await kafka.InsertPost(jsonPost, "crawler-preview-post");
                        #endregion

                        //while (indexLoadComment < 25)
                        //{
                        //    indexLoadComment++;
                        //    var checkJs1 = await Common.Utilities.EvaluateJavaScriptSync(_jsClickShowMoreHotel, _browser).ConfigureAwait(false);
                        //    if (checkJs1 == null)
                        //    {
                        //        break;
                        //    }
                        //    //await Task.Delay(5_000);
                        //    await Task.Delay(1_500);
                        //}

                        while (true)
                        {
                            string html1 = await Common.Utilities.GetBrowserSource(_browser).ConfigureAwait(false);
                            _document.LoadHtml(html1);
                            html1 = null;
                            //Lấy list comment
                            HtmlNodeCollection divComment = _document.DocumentNode.SelectNodes($"//div[contains(@class,'uitk-card-content-section uitk-card-content-section-border-block-end uitk-card-content-section-padded')][position()>{indexLastComment}]");
                            HtmlNode contentComment = _document.DocumentNode.SelectSingleNode($"//div[contains(@class,'rd-des')]/span[contains(@class,'ng-binding')]");
                            if (divComment == null)
                            {
                                break;
                            }

                            if (divComment != null)
                            {
                                foreach (HtmlNode item in divComment)
                                {
                                    DTO.CommentDTO commentDTO = new DTO.CommentDTO();
                                    commentDTO.Point = item.SelectSingleNode(".//h3[contains(@class,'uitk-heading uitk-heading-5')]/span")?.InnerText;
                                    string author = item.SelectSingleNode(".//section/h4[contains(@class,'uitk-heading uitk-heading-7')]")?.InnerText;
                                    commentDTO.Author = author;
                                    string commnent = Common.Utilities.RemoveSpecialCharacter(item.SelectSingleNode(".//div[contains(@class,'uitk-expando-peek-inner display-lines')]//span")?.InnerText);

                                    DateTime postDate = DateTime.Now;
                                    string datecomment = item.SelectSingleNode(".//section/div[contains(@class,'uitk-type-300 uitk-text-default-theme')]/span")?.InnerText;
                                    if (!string.IsNullOrEmpty(datecomment))
                                    {
                                        Common.DateTimeFormatAgain dtFomat = new Common.DateTimeFormatAgain();
                                        string date = dtFomat.GetDateByPattern(datecomment, "dd/MM/yyyy");

                                        try
                                        {
                                            postDate = Convert.ToDateTime(date);
                                        }
                                        catch(Exception ex) {
                                            var type = this.GetType().Name;
                                            Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
                                        }
                                    }
                                    commentDTO.PostDate = postDate;
                                    commentDTO.CreateDate = DateTime.Now;
                                    commentDTO.Domain = URL_EXPEDIA;
                                    commentDTO.ReferUrl = url;
                                    commentList.Add(commentDTO);

                                    #region gửi đi cho ILS

                                    CommentDTO_BigData enti = new CommentDTO_BigData();
                                    enti.post_Id = Common.Utilities.Md5Encode(url);
                                    enti.Comment = commnent;
                                    enti.Author = author;
                                    enti.Url = commentDTO.ReferUrl;
                                    // thời gian tạo tin
                                    enti.Create_time = postDate;
                                    enti.Create_Time_String = postDate.ToString("yyyy-MM-dd HH:mm:ss");

                                    //Get_Time là thời gian bóc 
                                    enti.Get_Time = DateTime.Now;
                                    enti.Get_Time_String = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                                    //enti.Url = commentDTO.ReferUrl;

                                    ////Get_Time là thời gian bóc 
                                    //enti.Get_Time = commentDTO.CreateDate;
                                    //enti.Get_Time_String = commentDTO.CreateDate.ToString("yyyy-MM-dd HH:mm:ss");

                                    string jsonPost1 = KafkaPreview.ToJson<CommentDTO_BigData>(enti);
                                    KafkaPreview kafka1 = new KafkaPreview();
                                    await kafka1.InsertPost(jsonPost1, "crawler-preview-post-comment");
                                    #endregion

                                    indexLastComment++;

                                }
                            }
                            ////Check nút xem thêm
                            //HtmlNode checkMoreItem = _document.DocumentNode.SelectSingleNode("//button[contains(@class,'uitk-button uitk-button-medium uitk-button-has-text uitk-button-secondary')]");
                            //if (checkMoreItem == null)
                            //{
                            //    break;
                            //}
                            //string checkJs = await Common.Utilities.EvaluateJavaScriptSync(_jsClickShowMoreReview, _browser).ConfigureAwait(false);
                            //if (checkJs == null)
                            //{
                            //    break;
                            //}
                            await Task.Delay(TimeSpan.FromSeconds(5));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                string error = ex.Message;
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }
            return commentList;
        }
    }
}
