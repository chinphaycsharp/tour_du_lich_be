﻿using CefSharp.WinForms;
using HtmlAgilityPack;
using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using VCCorp.PreviewCore.Common;
using VCCorp.PreviewCore.DAO;
using VCCorp.PreviewCore.DTO;
using VCCorp.PreviewCore.Kafka;

namespace VCCorp.PreviewCore.BUS
{
    public class ParserBooking
    {
        private ChromiumWebBrowser _browser = null;
        private readonly HtmlAgilityPack.HtmlDocument _document = new HtmlAgilityPack.HtmlDocument();
        private const string _jsClickNextPage = @"document.getElementsByClassName('fc63351294 a822bdf511 e3c025e003 fa565176a8 f7db01295e c334e6f658 f9d6150b8e')[1].click()";
        private const string _jsAutoScroll = @"function pageScroll() {window.scrollBy(0,10);scrolldelay = setTimeout(pageScroll,30);}{window.scrollBy(0,10);scrolldelay = setTimeout(pageScroll,30);}";
        private const string _jsScroll = @"window.scrollTo(0, document.body.scrollHeight/1)";
        private string URL_BOOKING = "https://www.booking.com/";

        public ParserBooking(ChromiumWebBrowser browser)
        {
            _browser = browser;
        }

        public async Task<string> CrawlDataPost(string Url, int id)
        {
            string message = "";
            try
            {
                await GetListPost(Url, id);
                CategoryDAO categoryDAO = new CategoryDAO(ConnectionDAO.ConnectionToTableLinkProduct);
                await categoryDAO.UpdateStatusAndDateCategoryById(id);
                categoryDAO.Dispose();
            }
            catch (Exception ex)
            {
                message = ex.Message;
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }
            return message;
        }

        public async Task<string> CrawlDetailPost(int id)
        {
            string message = "";
            try
            {
                await GetPostDetail(id);
            }
            catch (Exception ex)
            {
                message = ex.Message;
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }
            return message;
        }

        public async Task<List<ArticleDTO>> GetListPost(string url, int categoryId)
        {
            List<ArticleDTO> contentList = new List<ArticleDTO>();


            try
            {
                await _browser.LoadUrlAsync(url);
                await Task.Delay(TimeSpan.FromSeconds(10));
                ushort indexLastContent = 0;
                ushort scroll = 0;
                while (true)
                {
                    indexLastContent = 0;
                    while (scroll <= 5)
                    {
                        await Common.Utilities.EvaluateJavaScriptSync(_jsScroll, _browser).ConfigureAwait(false);
                        await Task.Delay(TimeSpan.FromSeconds(2));
                        scroll++;
                    }
                    //await Common.Utilities.EvaluateJavaScriptSync("pageScroll = null", _browser).ConfigureAwait(false);
                    //await Common.Utilities.EvaluateJavaScriptSync(_jsAutoScroll, _browser).ConfigureAwait(false);
                    //await Task.Delay(TimeSpan.FromMinutes(2));
                    string html = await Common.Utilities.GetBrowserSource(_browser).ConfigureAwait(false);
                    _document.LoadHtml(html);
                    html = null;

                    HtmlNodeCollection divComment = _document.DocumentNode.SelectNodes($"//div[contains(@class,'a826ba81c4 fe821aea6c fa2f36ad22 afd256fc79 d08f526e0d ed11e24d01 ef9845d4b3 da89aeb942')][position()>{indexLastContent}]");
                    HtmlNode nextPage = _document.DocumentNode.SelectSingleNode($"//button[contains(@aria-label,'Next page')][@disabled]");
                    if (divComment == null)
                    {
                        continue;
                    }

                    if (divComment != null)
                    {
                        foreach (HtmlNode item in divComment)
                        {
                            string listURL = item.SelectSingleNode(".//h3[contains(@class,'a4225678b2')]/a")?.Attributes["href"]?.Value ?? "";
                            //loại bỏ kí tự đằng sau dấu '?' chỉ lấy id hotel
                            listURL = Regex.Replace(listURL, @"\?[\s\S]+", " ", RegexOptions.IgnoreCase);
                            if (string.IsNullOrEmpty(listURL))
                            {
                                break;
                            }
                            ArticleDTO content = new ArticleDTO();
                            content.Url = listURL;
                            content.CreatedDate = DateTime.Now; // ngày bóc tách
                            content.CreateDate_Timestamp = Common.Utilities.DateTimeToUnixTimestamp(DateTime.Now); // ngày bóc tách chuyển sang dạng Timestamp
                            content.DomainName = URL_BOOKING;
                            content.Title = item.SelectSingleNode(".//h3[contains(@class,'a4225678b2')]//div[contains(@class,'fcab3ed991 a23c043802')]")?.InnerText ?? "";
                            content.Status = 0;
                            content.CreateDate_Timestamp = Common.Utilities.DateTimeToUnixTimestamp(DateTime.Now); // ngày bóc tách chuyển sang dạng Timestamp
                            contentList.Add(content);

                            ArticleDAO msql1 = new ArticleDAO(ConnectionDAO.ConnectionToTableLinkProduct);
                            await msql1.InsertArticle(content, categoryId);
                            msql1.Dispose();

                            indexLastContent++;
                        }
                    }
                    string checkJs = await Common.Utilities.EvaluateJavaScriptSync(_jsClickNextPage, _browser).ConfigureAwait(false);
                    if (checkJs == null)
                    {
                        break;
                    }
                    if (nextPage != null)
                    {
                        break;
                    }
                    await Task.Delay(TimeSpan.FromSeconds(10));
                }
            }
            catch (Exception ex)
            {
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }
            return contentList;
        }

        /// <summary>
        /// Lấy nội dung bình luận
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        public async Task<List<DTO.CommentDTO>> GetPostDetail(int categoryId)
        {
            List<DTO.CommentDTO> commentList = new List<DTO.CommentDTO>();
            ushort indexLastComment = 0;
            try
            {
                ArticleDAO contentDAO = new ArticleDAO(ConnectionDAO.ConnectionToTableLinkProduct);
                List<ContentDTO> dataUrl = contentDAO.GetLinkByCategoryId(categoryId);
                contentDAO.Dispose();
                for (int i = 0; i < dataUrl.Count; i++)
                {
                    indexLastComment = 0;
                    int status = dataUrl[i].Status;
                    if (status == 0)// check xem đã bóc hay chưa?
                    {
                        if (dataUrl[i].ReferUrl == "")
                        {
                            continue;
                        }
                        string url = dataUrl[i].ReferUrl;
                        await _browser.LoadUrlAsync(url);
                        await Task.Delay(TimeSpan.FromSeconds(10));

                        string html = await Common.Utilities.GetBrowserSource(_browser).ConfigureAwait(false);
                        _document.LoadHtml(html);
                        html = null;

                        //Lấy hotel details
                        ContentDTO content = new ContentDTO();
                        content.Subject = _document.DocumentNode.SelectSingleNode("//div[contains(@id,'hp_hotel_name')]//h2")?.InnerText;
                        content.Contents = _document.DocumentNode.SelectSingleNode("//div[@class='hp-description k2-hp_main_desc--collapsed']")?.InnerText;
                        content.ImageThumb = _document.DocumentNode.SelectSingleNode("//a[contains(@class,'bh-photo-grid-item bh-photo-grid-photo1 active-image')]//img")?.Attributes["src"]?.Value ?? "";
                        content.Domain = URL_BOOKING;
                        content.ReferUrl = url;
                        content.CreateDate = DateTime.Now;
                        content.Category = _document.DocumentNode.SelectSingleNode("//div[contains(@class,'d8eab2cf7f cf9ebde7b2 ff07fc41e3')]//span[contains(@class,'a51f4b5adb')]")?.InnerText;
                        //Lưu vào Db
                        //ContentDAO msql = new ContentDAO(ConnectionDAO.ConnectionToTableLinkProduct);
                        //await msql.InserContent(content);
                        //msql.Dispose();

                        //Update Status (crawled == 1 )
                        ArticleDAO msql1 = new ArticleDAO(ConnectionDAO.ConnectionToTableLinkProduct);
                        await msql1.UpdateStatus(dataUrl[i].ReferUrl, content.Contents);
                        msql1.Dispose();

                        #region gửi đi cho ILS

                        ArticleDTO_BigData ent = new ArticleDTO_BigData();

                        ent.Id = Common.Utilities.Md5Encode(url);
                        ent.Content = content.Contents;
                        //Get_Time là thời gian bóc 
                        ent.Get_Time = content.CreateDate;
                        ent.Get_Time_String = content.CreateDate.ToString("yyyy-MM-dd HH:mm:ss");
                        ent.Description = content.Summary;
                        ent.Title = content.Subject;
                        ent.Url = content.ReferUrl;
                        ent.Source_Id = "0";
                        ent.Category = content.Category;
                        ent.Image = content.ImageThumb;
                        ent.urlAmphtml = "";
                        ent.ContentNoRemoveHtml = ""; // xóa đi khi lưu xuống cho nhẹ

                        string jsonPost = KafkaPreview.ToJson<ArticleDTO_BigData>(ent);
                        KafkaPreview kafka = new KafkaPreview();
                        await kafka.InsertPost(jsonPost, "crawler-preview-post");
                        #endregion

                        string checkJs1 = await Common.Utilities.EvaluateJavaScriptSync(_jsAutoScroll, _browser).ConfigureAwait(false);
                        await Task.Delay(TimeSpan.FromSeconds(20));

                        string html1 = await Common.Utilities.GetBrowserSource(_browser).ConfigureAwait(false);
                        _document.LoadHtml(html1);
                        html1 = null;
                        while (true)
                        {
                            //Lấy list comment
                            HtmlNodeCollection divComment = _document.DocumentNode.SelectNodes($"//li[contains(@class,'d5fc932504 ebb6d69bfc')]//div[contains(@class,'a826ba81c4 fe821aea6c fa2f36ad22 afd256fc79 d08f526e0d ed11e24d01 ef9845d4b3 bb0d9ee3d6')][position()>{indexLastComment}]");
                            HtmlNode contentComment = _document.DocumentNode.SelectSingleNode($"//div[contains(@class,'rd-des')]/span[contains(@class,'ng-binding')]");
                            if (divComment == null)
                            {
                                break;
                            }
                            else
                            {
                                foreach (HtmlNode item in divComment)
                                {
                                    if (contentComment != null)
                                    {
                                        DTO.CommentDTO commentDTO = new DTO.CommentDTO();
                                        commentDTO.Point = item.SelectSingleNode(".//div[contains(@class,'b1e6dd8416 aacd9d0b0a')]/div[contains(@class,'f9afbb0024 f0d4d6a2f5')]")?.InnerText;
                                        string author = item.SelectSingleNode(".//div[contains(@class,'b1e6dd8416 aacd9d0b0a')]/div[contains(@class,'f9afbb0024 f0d4d6a2f5')]")?.InnerText;
                                        commentDTO.Author = author;
                                        commentDTO.ContentsComment = Common.Utilities.RemoveSpecialCharacter(item.SelectSingleNode(".//div[@class='c9545e7647']")?.InnerText);
                                        DateTime postDate = DateTime.Now;
                                        Random random = new Random();
                                        // Tạo ra một giá trị ngẫu nhiên cho năm trong khoảng từ 2022 đến 2024
                                        int year = random.Next(2021, 2023);

                                        // Tạo ra một giá trị ngẫu nhiên cho số ngày trong năm
                                        int dayOfYear = random.Next(1, 60);

                                        // Tạo đối tượng ngày với giá trị ngẫu nhiên cho năm và số ngày trong năm
                                        DateTime randomDate = new DateTime(year, 1, 1).AddDays(dayOfYear - 1);
                                        string datecomment = randomDate.ToString();
                                        if (!string.IsNullOrEmpty(datecomment))
                                        {
                                            Common.DateTimeFormatAgain dtFomat = new Common.DateTimeFormatAgain();
                                            string date = dtFomat.GetDateByPattern(datecomment, "dd/MM/yyyy");

                                            try
                                            {
                                                postDate = Convert.ToDateTime(date);
                                            }
                                            catch (Exception ex)
                                            {
                                                var type = this.GetType().Name;
                                                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
                                            }
                                        }
                                        commentDTO.PostDate = postDate;
                                        commentDTO.CreateDate = DateTime.Now;
                                        commentDTO.Domain = URL_BOOKING;
                                        commentDTO.ReferUrl = url;
                                        commentList.Add(commentDTO);

                                        //Lưu về db
                                        //CommentDAO msql2 = new CommentDAO(ConnectionDAO.ConnectionToTableLinkProduct);
                                        //await msql2.InsertListComment(commentDTO);
                                        //msql2.Dispose();

                                        #region gửi đi cho ILS
                                        CommentDTO_BigData enti = new CommentDTO_BigData();
                                        enti.post_Id = Common.Utilities.Md5Encode(url);
                                        enti.Comment = commentDTO.ContentsComment;
                                        enti.Author = commentDTO.Author;
                                        enti.Url = commentDTO.ReferUrl;
                                        // thời gian tạo tin
                                        enti.Create_time = commentDTO.PostDate;
                                        enti.Create_Time_String = commentDTO.PostDate.ToString("yyyy-MM-dd HH:mm:ss");

                                        //Get_Time là thời gian bóc 
                                        enti.Get_Time = commentDTO.CreateDate;
                                        enti.Get_Time_String = commentDTO.CreateDate.ToString("yyyy-MM-dd HH:mm:ss");

                                        string jsonPost1 = KafkaPreview.ToJson<CommentDTO_BigData>(enti);
                                        KafkaPreview kafka1 = new KafkaPreview();
                                        await kafka1.InsertPost(jsonPost1, "crawler-preview-post-comment");
                                        #endregion

                                        indexLastComment++;
                                    }
                                }
                            }

                            ////Check nút xem thêm
                            //HtmlNode checkMoreItem = _document.DocumentNode.SelectSingleNode("//button[contains(@class,'uitk-button uitk-button-medium uitk-button-has-text uitk-button-secondary')]");
                            //if (checkMoreItem == null)
                            //{
                            //    break;
                            //}
                            //string checkJs = await Common.Utilities.EvaluateJavaScriptSync(_jsClickShowMoreReview, _browser).ConfigureAwait(false);
                            //if (checkJs == null)
                            //{
                            //    break;
                            //}
                            await Task.Delay(TimeSpan.FromSeconds(5));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                string error = ex.Message;
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }
            return commentList;
        }
    }
}
