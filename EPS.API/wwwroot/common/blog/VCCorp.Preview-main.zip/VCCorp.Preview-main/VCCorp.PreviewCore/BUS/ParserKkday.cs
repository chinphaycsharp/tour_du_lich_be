﻿using CefSharp.WinForms;
using HtmlAgilityPack;
using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using VCCorp.PreviewCore.Common;
using VCCorp.PreviewCore.DAO;
using VCCorp.PreviewCore.DTO;
using VCCorp.PreviewCore.Kafka;

namespace VCCorp.PreviewCore.BUS
{
    public class ParserKKDay
    {
        private ChromiumWebBrowser _browser = null;
        private readonly HtmlAgilityPack.HtmlDocument _document = new HtmlAgilityPack.HtmlDocument();
        private const string _jsClickShowMoreComment = @"document.getElementsByClassName('ant-pagination-item-link')[1].click()";
        private const string _jsClickNextPage = @"document.getElementsByClassName('ant-pagination-item-link')[2].click()";
        private const string _jsScroll = @"window.scrollTo(0, document.body.scrollHeight/1)";
        private const string _jsAutoScroll = @"function pageScroll() {window.scrollBy(0,10);scrolldelay = setTimeout(pageScroll,30);}{window.scrollBy(0,10);scrolldelay = setTimeout(pageScroll,30);}";
        private string URL_KKDAY = "https://www.kkday.com";

        public ParserKKDay()
        {
        }
        public ParserKKDay(ChromiumWebBrowser browser)
        {
            _browser = browser;
        }

        public async Task<string> CrawlDataPost(string Url, int id)
        {
            string message = "";
            try
            {
                await GetListPost(Url, id);
                CategoryDAO categoryDAO = new CategoryDAO(ConnectionDAO.ConnectionToTableLinkProduct);
                await categoryDAO.UpdateStatusAndDateCategoryById(id);
                categoryDAO.Dispose();
            }
            catch (Exception ex)
            {
                message = ex.Message;
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }
            return message;
        }

        public async Task<string> CrawlDetailPost(int id)
        {
            string message = "";
            try
            {
                await GetPostDetail(id);
            }
            catch (Exception ex)
            {
                message = ex.Message;
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }
            return message;
        }

        /// <summary>
        /// Lấy list hotel
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        public async Task<List<ArticleDTO>> GetListPost(string url, int categoryId)
        {
            List<ArticleDTO> contentList = new List<ArticleDTO>();

            try
            {
                ushort indexLastContent = 0;
                ushort scroll = 0;
                for (int page = 1; page < 40; page++)
                {
                    indexLastContent = 0;
                    scroll = 0;
                    string[] splitUrl = url.Split('?');
                    string newUrl = splitUrl[splitUrl.Length - 2] + "?page=" + page + "&" + splitUrl[splitUrl.Length - 1];
                    await _browser.LoadUrlAsync(newUrl);
                    await Task.Delay(TimeSpan.FromSeconds(10));
                    while (scroll <= 5)
                    {
                        await Common.Utilities.EvaluateJavaScriptSync(_jsScroll, _browser).ConfigureAwait(false);
                        await Task.Delay(TimeSpan.FromSeconds(2));
                        scroll++;
                    }
                    string html = await Common.Utilities.GetBrowserSource(_browser).ConfigureAwait(false);
                    _document.LoadHtml(html);
                    html = null;

                    while (true)
                    {
                        HtmlNodeCollection divComment = _document.DocumentNode.SelectNodes($"//div[@class='product-card gtm-prod-card-element' or @class='product-listview search-info gtm-prod-card-element'][position()>{indexLastContent}]");
                        if (divComment == null)
                        {
                            break;
                        }
                        else
                        {
                            foreach (HtmlNode item in divComment)
                            {
                                string listURL = item.SelectSingleNode(".//a")?.Attributes["href"]?.Value ?? "";
                                //loại bỏ kí tự đằng sau dấu '?' chỉ lấy id hotel
                                listURL = Regex.Replace(listURL, @"\?[\s\S]+", " ", RegexOptions.IgnoreCase);
                                ArticleDTO content = new ArticleDTO();
                                content.Url = listURL;
                                content.CreatedDate = DateTime.Now; // ngày bóc tách
                                content.DomainName = URL_KKDAY;
                                content.Status = 0;
                                //div[@class='layout-list layout-list--gap-2 layout-list--horizontal-align-default' or @class='product-listview search-info gtm-prod-card-element']
                                content.Title = item.SelectSingleNode(".//div[contains(@class,'layout-list layout-list--gap-2 layout-list--horizontal-align-default')]//h3//span")?.InnerText ?? "";
                                if (content.Title == "")
                                {
                                    content.Title = item.SelectSingleNode(".//div[contains(@class,'product-detail')]//h3")?.InnerText ?? "";
                                }
                                contentList.Add(content);

                                ArticleDAO msql = new ArticleDAO(ConnectionDAO.ConnectionToTableLinkProduct);
                                await msql.InsertArticle(content, categoryId);
                                msql.Dispose();

                                indexLastContent++;
                            }
                        }
                        await Common.Utilities.EvaluateJavaScriptSync("pageScroll = null", _browser).ConfigureAwait(false);
                        //string checkJs1 = await Common.Utilities.EvaluateJavaScriptSync(_jsClickNextPage, _browser).ConfigureAwait(false);
                        //if (checkJs1 == null)
                        //{
                        //    break;
                        //}
                        await Task.Delay(TimeSpan.FromSeconds(10));
                    }
                }
            }
            catch (Exception ex)
            {
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }
            return contentList;
        }

        //public async Task<List<ArticleDTO>> GetListPost(string url, int categoryId)
        //{
        //    List<ArticleDTO> contentList = new List<ArticleDTO>();

        //    for (int i = 1; i < 10; i++)
        //    {
        //        string[] splitUrl = url.Split('?');
        //        string newUrl = splitUrl[splitUrl.Length - 2] + "?page=" + i + "&" + splitUrl[splitUrl.Length - 1];
        //        string html = Utilities.GetContentHtml(newUrl);
        //        if (string.IsNullOrEmpty(html))
        //        {
        //            return contentList;
        //        }
        //        else
        //        {
        //            string zone = Utilities.Xpath_GetHTML(html, "//div[contains(@class,'page-body')]", false);
        //            List<string> listHtmlArticle = Utilities.Xpath_GetListHTML(zone, "//article[contains(@class,'post-hotel-list-item hotel-item')]");
        //            if (listHtmlArticle != null && listHtmlArticle.Count > 0)
        //            {
        //                List<ArticleDTO> lisToReturn = new List<ArticleDTO>();
        //                ArticleDAO msql = new ArticleDAO(ConnectionDAO.ConnectionToTableLinkProduct);
        //                foreach (string articleHtml in listHtmlArticle)
        //                {
        //                    string subject = Utilities.Xpath_GetHTML(articleHtml, "//h2//a[contains(@class,'mihawk-detail-hotel')]", true); // truyền vào 1 đoạn xpath, xử lý xong trả ra đoạn text thỏa mã đoạn xpath đó, giá trị true để xóa đi các thẻ html giữ lại đoạn text
        //                    //string summary = Utilities.Xpath_GetHTML(articleHtml, "//p[contains(@class, 'description')]", true);

        //                    string imageThumb = "";
        //                    string imageThumbHtml = Utilities.Xpath_GetHTML(articleHtml, "//div[contains(@class,'post-thumbnail')]//a", false);
        //                    imageThumbHtml = Utilities.Regex_GetTextFromHtml(imageThumbHtml, "src[\\s]{0,}=[\\s]{0,}\".*?\"", "", "src[\\s]{0,}=[\\s]{0,}\"|\"", true);

        //                    // sau khi lấy url chỉ là tương đối, để rõ ràng cần nối thêm cái đầu https://vnexpress.net vào nữa
        //                    imageThumbHtml = Utilities.FixPathImage(imageThumbHtml, "");
        //                    if (imageThumbHtml.ToLower().Contains(".jpg") || imageThumbHtml.ToLower().Contains(".jpeg") || imageThumbHtml.ToLower().Contains(".png") || imageThumbHtml.ToLower().Contains(".gif"))
        //                    {
        //                        imageThumb = imageThumbHtml;
        //                    }

        //                    string link = Utilities.Xpath_GetHTML(articleHtml, "//div[contains(@class,'post-thumbnail')]//a", false);
        //                    link = Utilities.Regex_GetTextFromHtml(link, "(href[\\s]{0,}=[\\s]{0,}('|\")).*?('|\")", "", "(href[\\s]{0,}=[\\s]{0,}('|\"))|('|\")", true);
        //                    if (string.IsNullOrEmpty(link))
        //                    {
        //                        link = Utilities.Regex_GetTextFromHtml(link, "href=(.*?)(.html|.htm)", "", "href=", true);
        //                    }

        //                    // trang này không có đăng ngày tháng ở phần chuyên mục - mình sẽ bỏ qua
        //                    //string postDateString= Utilities.Xpath_GetHTML(articleHtml, "", true);

        //                    ArticleDTO obj = new ArticleDTO();
        //                    obj.Url = link;
        //                    obj.CreatedDate = DateTime.Now; // ngày bóc tách
        //                    obj.CreateDate_Timestamp = Common.Utilities.DateTimeToUnixTimestamp(DateTime.Now); // ngày bóc tách chuyển sang dạng Timestamp
        //                    obj.DomainName = URL_KKDAY;
        //                    obj.Title = subject;
        //                    obj.Status = 0;

        //                    lisToReturn.Add(obj);

        //                    await msql.InsertArticle(obj, categoryId);

        //                }
        //                msql.Dispose();
        //            }
        //        }
        //    }
        //    return contentList;
        //}

        /// <summary>
        /// Lấy nội dung bài viết + bình luận
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        public async Task<List<DTO.ContentDTO>> GetPostDetail(int categoryId)
        {
            List<DTO.ContentDTO> commentList = new List<DTO.ContentDTO>();
            try
            {
                //Lấy list Url hotel từ Db
                ArticleDAO contentDAO = new ArticleDAO(ConnectionDAO.ConnectionToTableLinkProduct);
                List<ContentDTO> dataUrl = contentDAO.GetLinkByCategoryId(categoryId);
                contentDAO.Dispose();

                //Đọc từng Url
                for (int i = 0; i < dataUrl.Count; i++)
                {
                    string url = dataUrl[i].ReferUrl;
                    await _browser.LoadUrlAsync(url);
                    await Task.Delay(TimeSpan.FromSeconds(10));
                    await Common.Utilities.EvaluateJavaScriptSync("pageScroll = null", _browser).ConfigureAwait(false);
                    await Common.Utilities.EvaluateJavaScriptSync(_jsAutoScroll, _browser).ConfigureAwait(false);
                    await Task.Delay(TimeSpan.FromSeconds(20));

                    string html = await Common.Utilities.GetBrowserSource(_browser).ConfigureAwait(false);
                    _document.LoadHtml(html);
                    html = null;

                    // Lấy detail content hotel
                    ContentDTO content = new ContentDTO();
                    content.TotalPoint = _document.DocumentNode.SelectSingleNode("//div[contains(@class,'layout-list-inline__item')]//b")?.InnerText;
                    content.Subject = _document.DocumentNode.SelectSingleNode("//div[contains(@class,'layout-flex-row__remain')]//h1[contains(@class,'product-title__name')]")?.InnerText;
                    content.Contents = Common.Utilities.RemoveSpecialCharacter(_document.DocumentNode.SelectSingleNode("//div[contains(@class,'info-section')]//div[@class='info-sec-collapsable expand']")?.InnerText);
                    content.Summary = _document.DocumentNode.SelectSingleNode("//div[contains(@class,'layout-flex-row__remain')]//h1[contains(@class,'product-title__name')]")?.InnerText;
                    content.ImageThumb = _document.DocumentNode.SelectSingleNode("//div[contains(@class,'splide__track')]//li[contains(@class,'splide__slide is-active is-visible')]//img")?.Attributes["src"]?.Value ?? "";
                    content.Domain = URL_KKDAY;
                    content.ReferUrl = url;
                    content.CreateDate = DateTime.Now;
                    content.Category = _document.DocumentNode.SelectSingleNode("//div[contains(@class,'critical-info')]//a[1]")?.InnerText;

                    if (content.Subject != null)
                    {
                        //Lưu vào Db
                        ArticleDAO msqlUpdate = new ArticleDAO(ConnectionDAO.ConnectionToTableLinkProduct);
                        await msqlUpdate.UpdateStatus(dataUrl[i].ReferUrl, content.Contents);
                        msqlUpdate.Dispose();

                        #region gửi đi cho ILS
                        ArticleDTO_BigData ent = new ArticleDTO_BigData();
                        ent.Id = Common.Utilities.Md5Encode(dataUrl[i].ReferUrl);
                        ent.Content = content.Contents;
                        //Get_Time là thời gian bóc 
                        ent.Get_Time = content.CreateDate;
                        ent.Get_Time_String = content.CreateDate.ToString("yyyy-MM-dd HH:mm:ss");
                        ent.Description = content.Summary;
                        ent.Title = content.Subject;
                        ent.Url = content.ReferUrl;
                        ent.Source_Id = "0";
                        ent.Category = content.Category;
                        ent.Image = content.ImageThumb;
                        ent.urlAmphtml = "";
                        ent.ContentNoRemoveHtml = ""; // xóa đi khi lưu xuống cho nhẹ

                        string jsonPost = KafkaPreview.ToJson<ArticleDTO_BigData>(ent);
                        KafkaPreview kafka = new KafkaPreview();
                        await kafka.InsertPost(jsonPost, "crawler-preview-post");
                        #endregion

                        //Lấy list comment
                        HtmlNodeCollection divComment = _document.DocumentNode.SelectNodes("//div[contains(@class,'review-item')]");
                        if (divComment != null)
                        {
                            foreach (HtmlNode item in divComment)
                            {
                                DTO.CommentDTO commentDTO = new DTO.CommentDTO();
                                commentDTO.Author = item.SelectSingleNode(".//div[contains(@class,'review-info-item')]//span")?.InnerText;
                                commentDTO.ContentsComment = Common.Utilities.RemoveSpecialCharacter(item.SelectSingleNode(".//div[contains(@class,'txt')]//p")?.InnerText);
                                DateTime postDate = DateTime.Now;
                                string datecomment = item.SelectSingleNode(".//div[@class='review-info']//div[@class='review-info-item'][2]//span")?.InnerText.Trim();
                                datecomment = Regex.Match(datecomment, @".+\d(?=\s)", RegexOptions.Singleline).Value;
                                if (!string.IsNullOrEmpty(datecomment))
                                {
                                    Common.DateTimeFormatAgain dtFomat = new Common.DateTimeFormatAgain();
                                    string date = dtFomat.GetDateByPattern(datecomment, "yyyy-MM-dd");
                                    try
                                    {
                                        postDate = Convert.ToDateTime(date);
                                    }
                                    catch (Exception ex)
                                    {
                                        var type = this.GetType().Name;
                                        Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
                                    }
                                }
                                commentDTO.PostDate = postDate;
                                commentDTO.CreateDate = DateTime.Now;
                                commentDTO.Domain = URL_KKDAY;
                                commentDTO.ReferUrl = url;
                                // commentList.Add(commentDTO);

                                #region gửi đi cho ILS
                                CommentDTO_BigData enti = new CommentDTO_BigData();
                                enti.post_Id = Common.Utilities.Md5Encode(dataUrl[i].ReferUrl);
                                enti.Comment = commentDTO.ContentsComment;
                                enti.Author = commentDTO.Author;
                                enti.Url = commentDTO.ReferUrl;
                                // thời gian tạo tin
                                enti.Create_time = commentDTO.PostDate;
                                enti.Create_Time_String = commentDTO.PostDate.ToString("yyyy-MM-dd HH:mm:ss");

                                //Get_Time là thời gian bóc 
                                enti.Get_Time = commentDTO.CreateDate;
                                enti.Get_Time_String = commentDTO.PostDate.ToString("yyyy-MM-dd HH:mm:ss");

                                string jsonPost1 = KafkaPreview.ToJson<CommentDTO_BigData>(enti);
                                KafkaPreview kafka1 = new KafkaPreview();
                                await kafka1.InsertPost(jsonPost1, "crawler-preview-post-comment");
                                #endregion
                            }
                        }
                        await Task.Delay(TimeSpan.FromSeconds(5));
                    }
                }
            }
            catch (Exception ex)
            {
                var type = this.GetType().Name;
                Utilities.WriteLogToTxtFile($"{type} {ex.Message}");
            }
            return commentList;
        }
    }
}
